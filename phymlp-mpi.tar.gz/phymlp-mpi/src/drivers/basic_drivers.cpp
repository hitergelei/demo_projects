/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   This file contributors: Evgeny Podryabinkin
 */

#include "basic_drivers.h"
#include <sstream>


using namespace std;


const char* exyzReader::tagname = {"exyz_reader"};

exyzReader::exyzReader(string _filename, Wrapper * _p_MLP, AnyPES* _p_PES)
{
    p_MLP = _p_MLP;
    filename = _filename;
    p_PES = _p_PES;
}

exyzReader::exyzReader(const Settings& settings, Wrapper * _p_MLP, AnyPES* _p_PES)
{
    InitSettings();
    ApplySettings(settings);
    PrintSettings();

    p_MLP = _p_MLP;
    p_PES = _p_PES;

    SetTagLogStream("exyz_reader", log_output); // 
}


// tag name of object


void exyzReader::Run()
{
#ifdef MLP_MPI
    if (!log_output.empty() && 
        log_output != "stdout" && 
        log_output != "stderr")
            log_output += '_' + to_string(mpi.rank);
#endif // MLP_MPI

    std::ifstream ifs;

    if (filename.find(' ', 0) != string::npos)
        ERROR("Whitespaces in filename restricted");
    ifs.open(filename, ios::binary);
    if (!ifs.is_open())
        ERROR("Can't open file \"" + filename + "\" for reading configurations");
//  else
//      Message("Configurations will be read from file \"" + filename + "\"");

//  SetLogStream(log_output);

    int exyzcntr = 0;
    while (exyz.Load(ifs) && exyzcntr<max_exyz_cnt)
    {
        if (exyzcntr++ % mpi.size != mpi.rank)
            continue;

        exyz.features["from"] = "database:" + filename;

        std::stringstream logstrm1;
        logstrm1 << "exyz reading: #" << exyzcntr 
                << " size: " << exyz.size()
                << ", EFS data: " 
                << (exyz.has_energy() ? 'E' : ' ')
                << (exyz.has_forces() ? 'F' : ' ') 
                << (exyz.has_stresses() ? 'S' : '-')
                << (exyz.has_site_energies() ? 'V' : '-')
                << (exyz.has_charges() ? 'Q' : '-')
                << std::endl;
        MLP_LOG(tagname,logstrm1.str());

        CalcEFS(exyz);
    }

    if ((exyzcntr % mpi.size != 0) && mpi.rank >= (exyzcntr % mpi.size))
    {
        Configuration exyz;  // empty exyz submitted. Important for parallel selection 
        CalcEFS(exyz);
    }

    Message("Reading configuration complete");
}
