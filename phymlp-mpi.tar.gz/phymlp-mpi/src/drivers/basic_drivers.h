/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   This file contributors: Evgeny Podryabinkin
 */

#ifndef MLP_BASIC_DRIVERS_H
#define MLP_BASIC_DRIVERS_H



/////

#include "../wrapper.h"
#include "../basic_PES.h"
#include <iostream>


// Basic class for all drivers (algorithms requiring PES and modifing configurations, e.g. MD, Relaxation, etc.)
//  For EFS calculation the driver uses its own CalcEFS(exyz) mehod that invokes either AnyPES->CalcEFS or Wrapper->CalcEFS
class AnyDriver // : protected InitBySettings//, protected LogWriting 
{
protected:
    void CalcEFS(Configuration & exyz)
    {
        if (p_MLP != nullptr)
            p_MLP->Process(exyz);
        else if (p_PES != nullptr)
            p_PES->CalcEFS(exyz);
        else
            ERROR("No PES specified");
    }

public:
    Wrapper* p_MLP = nullptr;
    AnyPES* p_PES = nullptr;// pointer to PES driver operates with
    virtual void Run() = 0;             // function starting the driving proces
    virtual ~AnyDriver() {};
};


// Driver taking configurations from file.
class exyzReader : public AnyDriver, protected InitBySettings
{
private:
    Configuration exyz;

protected:
    static const char* tagname;         // tag name of object

public:
    // default settings
    std::string filename = "";          //  filename
    int max_exyz_cnt = HUGE_INT;         //  limit of configurations to be read
    std::string log_output = "";        //  log

    exyzReader(std::string _filename, 
              Wrapper *_p_MLP=nullptr, 
              AnyPES *_p_PES=nullptr);
    exyzReader(const Settings& settings, 
              Wrapper* _p_MLP=nullptr, 
              AnyPES * _p_PES=nullptr);

    void InitSettings()
    {
        MakeSetting(filename, "exyz_filename");
        MakeSetting(max_exyz_cnt, "limit");
        MakeSetting(log_output, "log");
    }

    
    void Run();                         //  starts reading configuations from file
};


#endif //#ifndef MLP_BASIC_DRIVERS_H
