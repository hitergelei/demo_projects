/*   MLP is a software for Machine Learning Interatomic PES
 *   MLP is released under the "New BSD License", see the LICENSE file.
 *   Contributors: Alexander function, Evgeny Podryabinkin, Ivan Novikov
 */
#include "../common/mpi_stubs.h"
#include "../common/comm.h"
#include "../common/stdafx.h"
#include "../common/utils.h"
#include "MLP.h"
#include "MLP_commands.h"



int ExecuteCommand(const std::string& command,
    std::vector<std::string>& args,
    std::map<std::string, std::string>& opts)
{
    bool is_command_not_found = true;
    is_command_not_found = !Commands(command, args, opts);

    if (is_command_not_found)
#ifndef MLP_MLP
        std::cout << "Error: command " << command << " does not exist." << std::endl;
#else
        if (mpi.rank == 0) std::cout << "Error: command " << command << " does not exist." << std::endl;
#endif

    return 1;
}

int main(int argc, char *argv[])
{
#ifdef MLP_MPI
    MPI_Init(&argc, &argv);
    mpi.InitComm(MPI_COMM_WORLD);
#endif

    std::vector<std::string> args;
    std::map<std::string, std::string> opts;

    // parse argv to extract args and opts
    std::string command = "help";
    if (argc >= 2) command = argv[1];
    ParseOptions(argc-1, argv+1, args, opts);

    try {
        ExecuteCommand(command, args, opts);
    }
    catch (const MLPException& e) 
    { 
        std::string mess;
#ifdef MLP_MPI
        if (((std::string)e.What()).size() > 0)
            mess += "Rank " + std::to_string(mpi.rank) + ", ";
#endif
        mess += e.What();
        std::cerr << mess << std::endl;
        exit(777);
    }

#ifdef MLP_MPI
    MPI_Finalize();
#endif

    return 0;
}
