// /*   This software is called MLP for Machine Learning Interatomic PES.
//  *   MLP can only be used for non-commercial research and cannot be re-distributed.
//  *   The use of MLP must be acknowledged by citing approriate references.
//  *   See the LICENSE file for details.
//  *
//  *   This file contributors: Evgeny Podryabinkin
//  */

#ifndef MLP_BASIC_PES_H
#define MLP_BASIC_PES_H


#include "configuration.h"


//  Virtual basic class to be inherited by all classes representing interatomic interaction models
class AnyPES
{
protected:
    void ResetEFS(Configuration& exyz);                              // Sets EFS to 0.0 and has_... to true                  
public: 
    virtual void CalcEFS(Configuration& exyz) = 0;                   // Calculates energy, forces and stresses for exyz
    virtual void CalcE(Configuration& exyz) {    CalcEFS(exyz);   };  // Calculates energy for exyz
    virtual ~AnyPES() {};

    // Cheks forces and stresses to be energy derivative by finite differences. Returns true if deviation between FD-calculated and exact force is less than control_delta, 
    bool CheckEFSConsistency_debug( Configuration exyz,              // checks whether f = -dE/dx and stress = Lattice^(-T) * dE/d(Lattice) by finite differences
                                    double displacement=0.001,      // used in debug purposes
                                    double control_delta=0.00001);  // displacement - finite difference step, control_delta - tolerance
};

//  This PES does nothing and can be used as dummy in some objects calling PES when no EFS calculation is required. 
class VoidPES: public AnyPES
{
    void CalcE(Configuration&) {};
    void CalcEFS(Configuration&) {};
};

#endif //#ifndef MLP_BASIC_PES_H

