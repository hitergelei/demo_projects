/*   MLP is a software for Machine Learning Interatomic PES
 *   MLP is released under the "New BSD License", see the LICENSE file.
 *   Contributors: Alexander function, Evgeny Podryabinkin, Ivan Novikov
 */
#include <algorithm>
#include <sstream>
#include "MLP.h"
#include "../PhyMLPr_trainer.h"
#include "../drivers/basic_drivers.h"
#include "../exyz_selection.h"


bool RunAllTests(bool is_parallel);
using namespace std;


// does a number of unit tests (not dev)
// returns true if all tests are successful
// otherwise returns false and stops further tests

// bool self_test()
// {
//     ofstream logstream("temp/log");
//     SetStreamForOutput(&logstream);

// #ifndef MLP_DEBUG
//     if (mpi.rank == 0) {
//         std::cout << "Note: self-test is running without #define MLP_DEBUG;\n"
//             << "      build with -DMLP_DEBUG and run if troubles encountered" << std::endl;
//     }
// #endif

// #ifndef MLP_MPI
//     cout << "Serial tests:" << endl;
//     if (!RunAllTests(false)) return false;
// #else
//     if (mpi.rank == 0) 
//         cout << "mpi tests (" << mpi.size << " cores):" << endl;
//     if (!RunAllTests(true)) return false;
// #endif

//     logstream.close();
//     return true;
// }


bool Commands(const string& command, vector<string>& args, map<string, string>& opts)
{
    bool is_command_found = false;

    if (command == "list" || command == "help") 
    {
        if (command == "list" || args.size() == 0) is_command_found = true;
        if (mpi.rank == 0) 
        {
            cout << "MLP "
#ifdef MLP_MPI
                << "mpi version (" << mpi.size << " cores), "
#else
                << "serial version, "
#endif
                << "(C) A. function, E. Podryabinkin, I. Novikov (Skoltech).\n";
            if (command == "help" && args.size() == 0)
                cout << USAGE;
            if (command == "list")
                cout << "List of available commands:\n";
        }
    }

//     BEGIN_UNDOCUMENTED_COMMAND("run",
//         "reads configurations from a exyz_filename and processes them according to the settings specified in MLP.ini",
//         "MLP run MLP.ini exyz_filename [settings]:\n"
//         "Settings can be given in any order and are with the same names as in MLP.ini.\n"
//         "    Settings given from the command line overrides the settings taken from the file.\n"
//     )
//     {
//         if (args.size() != 2) {
//             cout << "MLP run: 2 argument required\n";
//             return 1;
//         }
//         string MLP_fnm = args[0];
//         Message("Settings are read from \""+MLP_fnm+"\"");
//         string read_exyz_fnm = args[1];
//         Message("Configurations are read from \""+read_exyz_fnm+"\"");

//         ios::sync_with_stdio(false);

//         Settings settings;
//         settings = LoadSettings(MLP_fnm);
//         settings.Modify(opts);

//         Wrapper MLP_wrapper(settings);

//         map<string, string> driver_settings;
//         driver_settings.emplace("exyz_filename", read_exyz_fnm);

//         exyzReader exyz_reader(driver_settings, &MLP_wrapper);

//         exyz_reader.Run();

//         Message("Configuration reading complete");
//     } END_COMMAND;

//     BEGIN_COMMAND("calculate_efs",
//         "calculate energy, forces and stresses for configurations from a file",
//         "MLP calculate_efs pot.PhyMLP exyz_filename [settings]:\n"
//         "reads configurations from a exyz_filename and calculates energy, forces and stresses for them"
//         "Settings can be given in any order"
//         "    --output_filename=<filename> file for output configurations. The same as exyz_filename by default.\n"
//     )
//     {
//         if (args.size() != 2) {
//             cout << "MLP calculate_efs: 2 arguments required\n";
//             return 1;
//         }
//         string MLP_filename = args[0];
//         string read_exyz_fnm = args[1];

//         MLPhyMLPR PhyMLP(MLP_filename);
//         Message("PhyMLP loaded from " + MLP_filename);

//         if (opts["output_filename"].empty())
//         {
//             auto exyzs = MPI_Loadexyzs(read_exyz_fnm);
//             Message("Configurations are read from \""+read_exyz_fnm+"\"");
//             for (auto& exyz : exyzs)
//                 PhyMLP.CalcEFS(exyz);
            
//             {
//                 ofstream ofs(read_exyz_fnm);
//                 if (!ofs.is_open())
//                     ERROR("Can't open output configurations file");
//             }

//             int max_count = 0;
//             int local_count = (int)exyzs.size();
//             MPI_Allreduce(&local_count, &max_count, 1, MPI_INT, MPI_MAX, mpi.comm);

//             for (Configuration& exyz : exyzs)
//                 for (int rnk=0; rnk<mpi.size; rnk++)
//                 {
//                     if (rnk == mpi.rank)
//                         exyz.AppendToFile(read_exyz_fnm);

//                     MPI_Barrier(mpi.comm);
//                 }
//             if (exyzs.size() < max_count)
//                 for (int rnk=0; rnk<mpi.size; rnk++)
//                     MPI_Barrier(mpi.comm);
//         }
//         else
//         {
//             ifstream ifs(read_exyz_fnm, ios::binary);
//             if (ifs.is_open())
//                 Message("Configurations are read from \""+read_exyz_fnm+"\"");
//             else
//                 ERROR("Can't open input configurations file");

//             string out_filename = opts["output_filename"] + mpi.fnm_ending;
//             {
//                 ofstream ofs(out_filename);
//                 if (!ofs.is_open())
//                     ERROR("Can't open output configurations file");
//             }

//             int count=0;
//             for (Configuration exyz; exyz.Load(ifs); count++)
//                  if (count % mpi.size == mpi.rank)
//                  {
//                      PhyMLP.CalcEFS(exyz);
//                      exyz.AppendToFile(out_filename);
//                  }
//         }

//         Message("EFS calculation complete");
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("add_species",
//         "adds species to an PhyMLP",
//         "MLP set_species pot.PhyMLP 0 1 2\n"
//         "Settings can be given in any order"
//         "    --random_parameters=<filename> initialize parameters randomly. True by default.\n"
//     )
//     {
//         if (args.size() < 2) {
//             cout << "MLP set_species: at least 2 arguments required\n";
//             return 1;
//         }
//         string MLP_filename = args[0];

//         bool init_random = true;
//         if (opts["random_parameters"] == "false" || opts["random_parameters"] == "False" || opts["random_parameters"] == "FALSE")
//             init_random = false;

//         MLPhyMLPR PhyMLP(MLP_filename);
//         Message("PhyMLP loaded from " + MLP_filename);

//         set<int> new_species_set;
//         for (int i=1; i<args.size(); i++)
//         {
//             int sp = stoi(args[i]);
//             if (sp<0)
//                 ERROR("Species numbers must be positive or zero");
//             new_species_set.insert(sp);
//         }
//         PhyMLP.AddSpecies(new_species_set, init_random);
//         PhyMLP.Save(MLP_filename);

//         Message("Species added");
//     } END_COMMAND;

//     BEGIN_COMMAND("relax",
//         "relaxes the configuration(s)",
//         "MLP relax pot.PhyMLP for_relax_filename relaxed_filename [settings]:\n"
//         "for_relax_filename is a file with the configurations for relaxation.\n"
//         "relaxed_filename is a file with the relaxed configurations.\n"
//         "Settings can be given in any order.\n"
//         "    --extrapolation_control=<true/false>: switch-on preselection if specified, not specified by default.\n"
//         "    --threshold_save=<double>: configurations with grade above this value (the preselected ones) will be saved to output file, default=2.1.\n"
//         "    --threshold_break=<double>: grade calculation will break if configuration grade is above this value, default=11.\n"
//         "    --save_extrapolative_to=<filename>: output file where preselected configurations will be saved, default: preselected.exyz.\n"
//         "    --save_unrelaxed=<filename>: exyz_relax_failed_filename is a file with the original configurations which relaxation failed.\n"
//         "    --relaxation_settings=<filename>: file with the settings for the relaxation driver.\n"
//         "    Settings given from the command line overrides the settings taken from the file.\n"
//     ) 
//     {
//         if (args.size() != 3)
//         {
//             cout << "MLP relax: 3 argument required\n";
//             return 1;
//         }
//         string PhyMLP_fnm = args[0];
//         Message("PES was read from \""+PhyMLP_fnm+"\"");
//         string read_exyz_fnm = args[1];
//         Message("Configurations are read from \""+read_exyz_fnm+"\"");
//         string relaxed_exyz_fnm = args[2];
//         Message("Relaxed configurations will be saved to \""+relaxed_exyz_fnm+"\"");

//         string unrelaxed_exyz_fnm;
//         if (!opts["save_unrelaxed"].empty())
//         {
//             unrelaxed_exyz_fnm = opts["save_unrelaxed"];
//             Message("Unrelaxed configurations will be saved to \""+relaxed_exyz_fnm+"\"");
//         }
//         string relaxation_settings_fnm = "";
//         if (!opts["relaxation_settings"].empty())
//         {
//             relaxation_settings_fnm = opts["relaxation_settings"];
//             Message("Relaxation settings will be loaded from \""+relaxation_settings_fnm+"\"");
//         }

//         Settings settings;
//         if (relaxation_settings_fnm != "") settings = LoadSettings(relaxation_settings_fnm);
//         settings.Modify(opts);
//         relaxed_exyz_fnm += mpi.fnm_ending;
//         if (!unrelaxed_exyz_fnm.empty())
//             unrelaxed_exyz_fnm += mpi.fnm_ending;

//         ios::sync_with_stdio(false);

//         // Fix settings, switch off settings enabling interprocessor communication
//         settings["MLP"] = "true";
//         settings["calculate_efs"] = "true";
//         settings["MLP:load_from"] = PhyMLP_fnm;
//         bool preselect = opts.count("extrapolation_control") > 0;
//         settings["extrapolation_control"] = "FALSE";
//         settings["extrapolation_control:threshold_save"] = to_string(2.1);
//         settings["extrapolation_control:threshold_break"] = to_string(10);
//         settings["extrapolation_control:save_extrapolative_to"] = "preselected.exyz";
//         if (preselect) {
//             settings["extrapolation_control"] = "TRUE";
//             if (!opts["threshold_save"].empty()) settings["extrapolation_control:threshold_save"] = opts["threshold_save"];
//             if (!opts["threshold_break"].empty()) settings["extrapolation_control:threshold_break"] = opts["threshold_break"];
//             if (!opts["save_extrapolative_to"].empty()) settings["extrapolation_control:save_extrapolative_to"] = opts["save_extrapolative_to"];
//         }
//         settings["fit"] = "FALSE";
//         if (settings["fit"] == "TRUE" ||
//             settings["fit"] == "True" ||
//             settings["fit"] == "true")
//             ERROR("Learning is not compatible with relaxation. \
//                    Change \"fit\" setting to \"FALSE\"");
//         if (settings["lotf"] == "TRUE" ||
//             settings["lotf"] == "True" ||
//             settings["lotf"] == "true")
//             ERROR("Learning is not compatible with relaxation. \
//                    Change \"lotf\" setting to \"FALSE\"");
//         if (settings["select:update_active_set"] == "TRUE" ||
//             settings["select:update_active_set"] == "True" ||
//             settings["select:update_active_set"] == "true")
//             ERROR("Active set update is not allowed while relaxation. \
//                    Change \"select:update_active_set\" setting to \"FALSE\"");

//         Wrapper MLP_wrapper(settings);

//         Settings driver_settings(settings.ExtractSubSettings("relax"));

//         Relaxation rlx(driver_settings, &MLP_wrapper);

//         ofstream ofs_relaxed, ofs_unrelaxed;
//         // check and clean output files
//         ifstream ifs(read_exyz_fnm, ios::binary);
//         if (!ifs.is_open())
//             ERROR("Cannot open \"" + read_exyz_fnm + "\" file for input");
//         ofs_relaxed.open(relaxed_exyz_fnm, ios::binary);
//         if (!ofs_relaxed.is_open())
//             ERROR("Cannot open \"" + relaxed_exyz_fnm + "\" file for output");

//         if (relaxed_exyz_fnm != unrelaxed_exyz_fnm && !unrelaxed_exyz_fnm.empty())
//         {
//             ofs_unrelaxed.open(unrelaxed_exyz_fnm, ios::binary);
//             if (!ofs_unrelaxed.is_open())
//                 ERROR("Cannot open \"" + unrelaxed_exyz_fnm + "\" file for output");
//         }

//         int relaxed_proc=0;

//         Configuration exyz_orig;                                //to save this exyz if failed to relax
//         int count=0;
//         bool error;                                            //was the relaxation successful or not
//         for (Configuration exyz; exyz.Load(ifs); count++)
//             if (count%mpi.size == mpi.rank)
//             {
//                 if (exyz.size() != 0)
//                 {
//                     error = false;
//                     exyz_orig = exyz;
//                     rlx.exyz = exyz;

//                     try { rlx.Run(); }
//                     catch (MLPException& e) {
//                         Warning("Relaxation of exyz#"+to_string(count+1)+" failed: "+e.message);
//                         error = true;
//                     }

//                     if (!error) 
//                     {
//                         rlx.exyz.Save(ofs_relaxed);
//                         relaxed_proc++;
//                     }
//                     else if (!unrelaxed_exyz_fnm.empty()) 
//                     {
//                         if (rlx.exyz.features["from"]=="" || 
//                             rlx.exyz.features["from"]=="relaxation_OK")
//                             rlx.exyz.features["from"]="relaxation_FAILED";

//                         if (relaxed_exyz_fnm != unrelaxed_exyz_fnm)
//                             exyz_orig.Save(ofs_unrelaxed);
//                         else 
//                             exyz_orig.Save(ofs_relaxed);
//                     }
//                 }
//             }

//         int relaxed_total=relaxed_proc;
//         MPI_Allreduce(&relaxed_proc, &relaxed_total, 1, MPI_INT, MPI_SUM, mpi.comm);

//         Message("From " + to_string(count) + " configurations " + to_string(relaxed_total) + " were relaxed successfully\n");

//     } END_COMMAND;

//     BEGIN_COMMAND("select_add",
//         "Actively selects configurations to be added to the current training set",
//         "MLP select_add pot.PhyMLP train_set.exyz candidates.exyz new_selected.exyz:\n"
//         "actively selects configurations from candidates.exyz and saves to new_selected.exyz those that are required to update the current training set (in train_set.exyz)\n"
//         "The specified selection weights overwrites the weights stored in PhyMLP file (if PhyMLP file contain the selection state). Default values of weights are set only if PhyMLP file has no selection state data and the weights are not specified by options"
//         "  Options:\n"
// //        "  --energy_weight=<double>: set the weight for energy equation, default=1\n"
// //        "  --force_weight=<double>: set the weight for force equations, default=0\n"
// //        "  --stress_weight=<double>: set the weight for stress equations, default=0\n"
// //        "  --site_en_weight=<double>: set the weight for site energy equations, default=0\n"
// //        "  --weight_scaling=<0 or 1 or 2>: how energy and stress weights are scaled with the number of atoms. final_energy_weight = energy_weight/N^(weight_scaling/2)\n"
//         "  --swap_limit=<int>: swap limit for multiple selection, unlimited by default\n"
// //        "  --batch_size=<int>: size of batch, default=9999 \n"
// //        "  --save_to=<string>: save maxvol state to a new PhyMLP file\n"
// //        "  --save_selected_to=<string>: filename for saving the active set\n"
// //        "  --threshold=<double>: set the select threshold to num, default=1.001\n"
//         "  --log=<string>: where to write the selection log, default="" (none) \n"
//     ) {

//         if (args.size() != 4) {
//             std::cout << "\tError: 4 arguments required\n";
//             return 1;
//         }

//         const string PhyMLP_filename = args[0];
//         const string train_filename = args[1];   
//         const string candidates_filename = args[2];
//         const string new_selected_filename = args[3];

//         int selection_limit=0;                      //limits the number of swaps in MaxVol

//         Settings settings;

//         settings.Modify(opts);

//         MLPhyMLPR PhyMLP(PhyMLP_filename);
//         Message("PhyMLP loaded from " + PhyMLP_filename);

//         exyzSelection select(&PhyMLP, settings);
//         if (settings.GetMap().count("energy_weight") == 0 &&
//             settings.GetMap().count("force_weight") == 0 &&
//             settings.GetMap().count("stress_weight") == 0 &&
//             settings.GetMap().count("site_en_weight") == 0 &&
//             settings.GetMap().count("weight_scaling") == 0)
//         {
//             try { select.Load(args[0]); }
//             catch (MLPException& excp) { Message(excp.What()); }
//         }
// //        select.Reset();

//         auto train_exyzs = MPI_Loadexyzs(train_filename);
//         Message("Training set loaded from " + train_filename);

//         // selection from training set
//         for (auto& exyz : train_exyzs)
//             select.AddForSelection(exyz);
//         double threshold_backup = select.threshold_select;
//         select.threshold_select = 1.001; // set minimal threshold for selection from the training set
//         select.Select();
//         select.threshold_select = threshold_backup; // restore given threshold
//         train_exyzs.clear();
//         int local = (int)select.selected_exyzs.size();
//         int global;
//         MPI_Reduce(&local, &global, 1, MPI_INT, MPI_SUM, 0, mpi.comm);
//         Message(to_string(global) + " configurations selected from training set");

//         // selection from candidates
//         ifstream ifs(candidates_filename, ios::binary);
//         if (!ifs.is_open())
//             ERROR("Can't open file \"" + candidates_filename + "\" for reading configurations");
//         int count = 0;
//         for (Configuration exyz; exyz.Load(ifs); count++)
//         {
//             if (count % mpi.size == mpi.rank)
//             {
//                 exyz.features["!@$%^&is_new"] = "true";
//                 select.Process(exyz);
//             }
//         }
//         ifs.close();
//         Configuration exyz;
//         if ((count % mpi.size != 0) && mpi.rank >= (count % mpi.size))
//             select.Process(exyz);
//         select.Select((select.swap_limit>0) ? select.swap_limit : HUGE_INT);
//         Message("Loading and selection of candidates completed");
        
//         // selecting from training set again
//         train_exyzs = MPI_Loadexyzs(train_filename);
//         for (auto& exyz : train_exyzs)
//             select.AddForSelection(exyz);
//         threshold_backup = select.threshold_select;
//         select.Select();
//         select.threshold_select = 1.001; // set minimal threshold for selection from the training set
//         select.threshold_select = threshold_backup; // restore given threshold
//         train_exyzs.clear();

//         // saving freshely selected configurations
//         if (mpi.rank == 0)
//             ofstream ofs(new_selected_filename); // clean output file

//         count = 0;
//         for (int rnk=0; rnk<mpi.size; rnk++)
//         {
//             if (rnk == mpi.rank)
//             {
//                 ofstream ofs(new_selected_filename, ios::binary | ios::app);
//                 if (!ofs.is_open())
//                     ERROR("Can not open file \"" + new_selected_filename+ "\" for output");

//                 for (Configuration& exyz : select.selected_exyzs)
//                 {
//                     if (exyz.features["!@$%^&is_new"] == "true" && exyz.size() > 0)
//                     {
//                         exyz.features.erase("!@$%^&is_new");

//                         exyz.features.erase("selected_eqn_inds");
//                         int first = *exyz.fitting_items.begin();
//                         for (int ind : exyz.fitting_items)
//                             exyz.features["selected_eqn_inds"] += ((ind == first) ? "" : ",") + to_string(ind);

//                         exyz.Save(ofs, Configuration::SAVE_GHOST_ATOMS);
//                         count++;
//                     }
//                     else
//                         exyz.features.erase("!@$%^&is_new");
//                 }
//             }

//             MPI_Barrier(mpi.comm);
//         }

//         int new_count=0;
//         MPI_Allreduce(&count, &new_count, 1, MPI_INT, MPI_SUM, mpi.comm);
//         if (mpi.rank==0)
//             cout << "Training set was increased by " << new_count << " configurations" << endl;

//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("sample",
//         "separates and saves the configurations with the high extrapolation grade",
//         "MLP sample MLP.PhyMLP in.exyz sampled.exyz [options]:\n"
//         "actively samples the configurations from in.exyz and saves them to sampled.exyz\n"
//         "  Options:\n"
//         "  --threshold_save=<double>: configurations with grade above this value will be saved to output file, default=2.1\n"
//         "  --threshold_break=<double>: grade calculation will break if configuration grade is above this value, default=11\n"
//         "  --add_grade_feature=<bool>: adds grade as a feature to configurations, default true"
//         "  --log=<string>: log, default=stdout\n"
//     ) {
//         if (args.size() != 3) {
//             std::cout << "\tError: 3 arguments required\n";
//             return 1;
//         }

//         const string PhyMLP_filename = args[0];
//         const string input_filename = args[1];
//         string output_filename = args[2];

//         cout << "PhyMLPR from " << PhyMLP_filename
//             << ", input: " << input_filename
//             << endl;
//         MLPhyMLPR PhyMLPr(PhyMLP_filename);

//         Settings settings;
//         settings["add_grade_feature"] = "true";
//         settings["save_extrapolative_to"] = output_filename;
//         if (settings["log"] != "none")
//             settings["log"] = "stdout";
//         else
//             settings["log"] = "";
//         settings.Modify(opts);

//         exyzSampling sampler(&PhyMLPr, PhyMLP_filename, settings);

//         Message("Starting grades evaluation");

//         ifstream ifss(input_filename, ios::binary);
//         if (!ifss.is_open())
//             ERROR("Can't open file \"" + input_filename + "\" for reading configurations");
//         int count = 0;
//         for (Configuration exyz; exyz.Load(ifss); count++)
//             if (count % mpi.size == mpi.rank)
//                 sampler.Evaluate(exyz);

//         if (mpi.rank == 0)
//             Message("Sampling complete");
//     } END_COMMAND;

    BEGIN_COMMAND("train",
        "fits an PhyMLP",
        "MLP train PES.PhyMLP train_set.exyz [options]:\n"
        "  trains PES.PhyMLP on the training set from train_set.exyz\n"
        "  Options include:\n"
        "    --save_to=<string>: filename for trained PES. By default equal to the first argument (overwrites input PhyMLP file)\n"
        "    --energy_weight=<double>: weight of energies in the fitting. Default=1\n"
        "    --force_weight=<double>: weight of forces in the fitting. Default=0.01\n"
        "    --stress_weight=<double>: weight of stresses in the fitting. Default=0.001\n"
        "    --weight_scaling=<0 or 1 or 2>: defines how energy and stress weights are scaled with the number of atoms (when fitting to configuration of different size). Default=1.0\n"
        "    --weight_scaling_forces=<0 or 1 or 2>: defines how forces weights are scaled with the number of atoms (when fitting to configuration of different size). Default=0.0\n"
        "        Typical combinations of weight_scaling and weight_scaling_forces: \n"
        "           1) weight_scaling=1, weight_scaling_forces=0 used for fiting the configurations sampled from MD trajectories \n"
        "           2) weight_scaling=0, weight_scaling_forces=0 used for fiting of molecules (non-periodic) \n"
        "           3) weight_scaling=2, weight_scaling_forces=1 used for fiting of structures (periodic) \n"
        "    --scale_by_force=<double>: if >0 wights for the small forces increse. Default=0\n"
        "    --iteration_limit=<int>: maximal number of iterations. Default=1000\n"
        "    --tolerance=<double>: stopping criterion for optimization. Default=1e-8\n"
        "    --init_random=<bool>: Initialize parameters if a not pre-fitted PhyMLP. Default is false - this is when interaction of all species is the same (more accurate fit, but longer optimization)\n"
//        "    --skip_preinit=<bool>: skip the 75 iterations done when params are not given\n"
        "    --no_mindist_update=<bool>: if true prevent updating of mindist parameter with actual minimal interatomic distance in the training set. Default=false\n"
        "    --al_mode=<exyz or nbh>: Active learning mode: by configuration (exyz) or by neighborhoods (nbh). Applicable only for training from scratch. Default=exyz\n"
        "    --log=<string>: where to write log. --log=none switches logging off. Default=stdout\n"
    ) {
        if (args.size() != 2) 
        {
            cout << "MLP train: 2 arguments are required\n";
            return 1;
        }

        Settings settings;
        settings.Modify(opts);

        if (settings["log"]=="")
            settings["log"]="stdout";
        if (settings["log"]=="none")
            settings["log"]="";
        if (settings["save_to"]=="")
            settings["save_to"]=args[0];
        if (settings["al_mode"]=="")
            settings["al_mode"]="exyz";

        SetTagLogStream("dev", &std::cout);
        MLPhyMLPR PhyMLP(args[0]);

        bool has_selection = false;
        double sel_ene_wgt = 0.0;
        double sel_frc_wgt = 0.0;
        double sel_str_wgt = 0.0;
        double sel_nbh_wgt = 0.0;
        int sel_wgt_scl = 2;
        
        {
            ifstream ifs(args[0], ios::binary);
            ifs.ignore(HUGE_INT, '#');
            if (ifs.fail() || ifs.eof())
            {
                Message("Selection data was not found in PhyMLP and will be set");
                if (settings["al_mode"] == "nbh")
                {
                    Message("Selection by neighborhoods is set");
                    sel_nbh_wgt = 1.0;
                }
                else if (settings["al_mode"] == "exyz")
                {
                    Message("Selection by configurations is set");
                    sel_ene_wgt = 1.0;
                }
                else
                {
                    ERROR("Invalid al_mode");
                }
            }
            else
            {
                Message("Selection data found");

                has_selection = true;

                string tmpstr;
                ifs >> tmpstr;
                if (tmpstr != "MVS_v1.1")
                    ERROR("Invalid MVS-file format");

                ifs >> tmpstr;
                if (tmpstr != "energy_weight")
                    ERROR("Invalid MVS-file format");
                ifs >> sel_ene_wgt;

                ifs >> tmpstr;
                if (tmpstr != "force_weight")
                    ERROR("Invalid MVS-file format");
                ifs >> sel_frc_wgt;

                ifs >> tmpstr;
                if (tmpstr != "stress_weight")
                    ERROR("Invalid MVS-file format");
                ifs >> sel_str_wgt;

                ifs >> tmpstr;
                if (tmpstr != "site_en_weight")
                    ERROR("Invalid MVS-file format");
                ifs >> sel_nbh_wgt;

                ifs >> tmpstr;
                if (tmpstr != "weight_scaling")
                    ERROR("Invalid MVS-file format");
                ifs >> sel_wgt_scl;
            }
        }

#ifdef MLP_MPI
        vector<Configuration> training_set = MPI_Loadexyzs(args[1]);
#else
        vector<Configuration> training_set = Loadexyzs(args[1]);
#endif
        // training
        PhyMLPR_trainer PhyMLPtr(&PhyMLP, settings);
        // std::cout << "MLP_command中的代码：初始化PhyMLPtr成功" << std::endl;


        // std::cout << "开始输出training_set的内容："<< std::endl;

        PhyMLPtr.Train(training_set);    // hjchen: 这里的结果与cfg的类型计算结果不一致！！！training_set本来应该是一个vector，里面存放的是所有的构型
        // std::cout << "MLP_command中的代码：Train模块执行成功" << std::endl;

        // training errrors calculation
        Settings erm_settings;
        erm_settings["reprt_to"] = settings["log"];
        ErrorMonitor errmon(erm_settings);
        for (Configuration& exyz : training_set)
        {
            Configuration exyz_check(exyz);
            PhyMLP.CalcEFS(exyz_check);
            errmon.AddToCompare(exyz, exyz_check);
        }
        errmon.GetReport();

        {
            Settings select_setup;
            exyzSelection select(&PhyMLP, select_setup);
                    //    if (has_selection)
            // {
            //     select.MV_ene_cmpnts_weight = sel_ene_wgt;
            //     select.MV_frc_cmpnts_weight = sel_frc_wgt;
            //     select.MV_str_cmpnts_weight = sel_str_wgt;
            //     select.MV_nbh_cmpnts_weight = sel_nbh_wgt;
            //     select.wgt_scale_power = sel_wgt_scl;
            // }

            // for (auto& exyz : training_set)
            //     select.AddForSelection(exyz);

            // select.Select();

            select.Save(settings["save_to"]);
        }

        Message("training complete");
    } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("select",
//         "Acively selects configurations from a pull and adds the selection state data to an PhyMLP",
//         "MLP select PhyMLP_filename exyz_filename [options]:\n"
//         "Settings can be given in any order.\n"
//         "  Options include:\n"
//         "  --energy_weight=<double>: set the weight for energy equation, default=1\n"
//         "  --force_weight=<double>: set the weight for force equations, default=0\n"
//         "  --stress_weight=<double>: set the weight for stress equations, default=0\n"
//         "  --site_en_weight=<double>: set the weight for site energy equations, default=0\n"
//         "  --weight_scaling=<0 or 1 or 2>: how energy and stress weights are scaled with the number of atoms. final_energy_weight = energy_weight/N^(weight_scaling/2)\n"
//         "  --save_to=<string>: were to save PhyMLP with selection state data, equal to the first argument by default\n"
//         "  --save_selected_to=<string>: were to save selected configurations, default="" (not saved)\n"
//         "  --batch_size=<int>: Configurations are committed for selection by batches. Configuratoions are accumulated in batch until the number of committed configurations reaches this number. After that, selection among all collected configurations is performed. Unlimited if 0 is set"
//         "  --log=<int>: Where to write selection log. \"stdout\" and \"stderr\" corresponds to standard output streams; Default="" (none)"
//     )
//     {
//         if (args.size() != 2) 
//         {
//             cout << "MLP select: 2 argument required\n";
//             return 1;
//         }

//         Settings settings;
//         if (!opts["settings_file"].empty())
//             settings = LoadSettings(opts["settings_file"]);
//         settings.Modify(opts);

//         if (settings["save_to"].empty())
//             settings["save_to"] = args[0];

//         MLPhyMLPR PhyMLP(args[0]);
//         exyzSelection selector(&PhyMLP, settings);

// #ifdef MLP_MPI
//         auto exyzs = MPI_Loadexyzs(args[1]);
// #else 
//         auto exyzs = Loadexyzs(args[1]);
// #endif

//         for (auto& exyz : exyzs)
//             exyz.InitNbhs(PhyMLP.CutOff());

//         for (auto& exyz : exyzs)
//             selector.Process(exyz);

//         selector.Select();

//     } END_COMMAND;

//     BEGIN_COMMAND("check_errors",
//         "calculates EFS for configuraion in database and compares them with the provided",
//         "MLP check_errors MLP.PhyMLP db.exyz:\n"
//         "calculates errors of \"MLP.PhyMLP\" on the database \"db.exyz\"\n"
//         "  Options include:\n"
//         "  --report_to <string> where to write the integral report. Default=stdout\n"
//         "  --log <string> where to write the report for each configuration\n"
//     ) {

//         if (args.size() < 2) {
//             cout << "MLP check_errors: 2 arguments are required\n";
//             return 1;
//         }

//         Settings settings;
//         settings.Modify(opts);

//         MLPhyMLPR PhyMLP(args[0]);

//         ErrorMonitor errmon(settings);

//         ifstream ifs(args[1], ios::binary);
//         if (!ifs.is_open())
//         {
//             Message("Can not open a file with configurations \""+args[1]+"\" for reading");
//         }
//         Configuration exyz;
//         int count=0;
//         for (; exyz.Load(ifs); count++)
//             if (count % mpi.size == mpi.rank)
//             {
//                 Configuration exyz_copy(exyz);
//                 PhyMLP.CalcEFS(exyz_copy);
//                 errmon.AddToCompare(exyz, exyz_copy);
//             }
//         if ((count % mpi.size != 0) && mpi.rank >= (count % mpi.size))
//             errmon.AddToCompare(exyz, exyz);

//         errmon.GetReport();

//     } END_COMMAND;

//     BEGIN_COMMAND("cut_extrapolative_nbh",
//         "converts neighborhood to sperical configuration (non-periodic boundary conditions)",
//         "MLP cut_extrapolative_nbh in.exyz out.exyz [options]:\n"
//         "for each configuration in \"in.exyz\" finds the neighborhood with the maximal extrapolation grade,\n"
//         "  converts it to the non-periodic configuration cut from in.exyz, and saves it in \"out.exyz\"\n"
//         "  Options include:\n"
//         "  --cutoff=<double>: set cutoff radius of sphere to cut from in.exyz. Default=7.0 Angstrom\n"
// //        "  --no_save_additional_atoms: indicate do not save atoms beyond the sphere.\n"
// //        "  --threshold_save=<double>: extrapolative environments with the extrapolation grade higher then this value will be saved. Default: 3.0\n"
//     ) {

//         if (args.size() != 2) {
//             cout << "MLP cut_extrapolative_nbh: 2 arguments required\n";
//             return 1;
//         }

//         double cutoff = 7.0;
//             if (opts["cutoff"] != "") 
//                 cutoff = stod(opts["cutoff"]);

//         ifstream ifs(args[0]);
//         ofstream ofs(args[1]);
//         ofs.close();

//         Configuration exyz;

//         int cntr = 0;
//         while (exyz.Load(ifs))
//         {
//             int i = -1;
//             double max_grade = 0.0;
//             for (int j=0; j<exyz.size(); j++) 
//                 if (exyz.nbh_grades(j) > max_grade) 
//                 {
//                     max_grade = exyz.nbh_grades(j);
//                     i = j;
//                 }
//             if (max_grade < 1.1)
//                 continue;

//             exyz.InitNbhs(cutoff);

//             Configuration nbh;
//             nbh.features["exyz#"] = to_string(cntr);
//             nbh.features["nbh#"] = to_string(i);
//             nbh.features["extrapolation_grade"] = to_string(exyz.nbh_grades(i));
//             nbh.resize(exyz.nbhs[i].count + 1);
//             nbh.pos(0) = Vector3(0, 0, 0);
//             nbh.type(0) = exyz.type(i);
                
//             for (int j=0; j<exyz.nbhs[i].count; j++)
//             {
//                 nbh.pos(j+1) = exyz.nbhs[i].vecs[j];
//                 nbh.type(j+1) = exyz.nbhs[i].types[j];
//             } 
                    
//             nbh.AppendToFile(args[1]);

//             cout << "from exyz#" << cntr+1 << " cut nbh#" << i << " with grade=" << max_grade << " (atoms count is " << exyz.nbhs[i].count << ')' << endl;
//             cntr++;
// /*
//             if (exyz.lattice.det() != 0.0)
//             {

//                 Vector3 v1(exyz.lattice[0][0], exyz.lattice[0][1], exyz.lattice[0][2]);
//                 Vector3 v2(exyz.lattice[1][0], exyz.lattice[1][1], exyz.lattice[1][2]);
//                 Vector3 v3(exyz.lattice[2][0], exyz.lattice[2][1], exyz.lattice[2][2]);
            
//                 Vector3 n3 = Vector3::VectProd(v1, v2) / Vector3::VectProd(v1, v2).Norm();
//                 Vector3 n2 = Vector3::VectProd(v1, v3) / Vector3::VectProd(v1, v3).Norm();
//                 Vector3 n1 = Vector3::VectProd(v3, v2) / Vector3::VectProd(v3, v2).Norm();
                
//                 int times1 = ceil((n1 * (n1 * v1)).Norm() / cutoff);
//                 int times2 = ceil((n2 * (n2 * v2)).Norm() / cutoff);
//                 int times3 = ceil((n3 * (n3 * v3)).Norm() / cutoff);
            
//                 int sz = exyz.size();
//                 for (int i=1; i<=times1; i++)
//                 {
//                     int oldsz = exyz.size();
//                     exyz.resize(oldsz + sz);
//                     for (int j=0; j<sz; j++)
//                     {
//                         exyz.pos(oldsz + j) = exyz.pos(j) + v1*i;
//                         exyz.type(oldsz + j) = exyz.type(j);
//                     }
//                     oldsz = exyz.size();
//                     exyz.resize(oldsz + sz);
//                     for (int j=0; j<sz; j++)
//                     {
//                         exyz.pos(oldsz + j) = exyz.pos(j) - v1*i;
//                         exyz.type(oldsz + j) = exyz.type(j);
//                     }
//                 }
//                 for (int i=1; i<=times2; i++)
//                 {
//                     int oldsz = exyz.size();
//                     exyz.resize(oldsz + sz);
//                     for (int j=0; j<sz; j++)
//                     {
//                         exyz.pos(oldsz + j) = exyz.pos(j) + v2*i;
//                         exyz.type(oldsz + j) = exyz.type(j);
//                     }
//                     oldsz = exyz.size();
//                     exyz.resize(oldsz + sz);
//                     for (int j=0; j<sz; j++)
//                     {
//                         exyz.pos(oldsz + j) = exyz.pos(j) - v2*i;
//                         exyz.type(oldsz + j) = exyz.type(j);
//                     }
//                 }
//                 for (int i=1; i<=times3; i++)
//                 {
//                     int oldsz = exyz.size();
//                     exyz.resize(oldsz + sz);
//                     for (int j=0; j<sz; j++)
//                     {
//                         exyz.pos(oldsz + j) = exyz.pos(j) + v3*i;
//                         exyz.type(oldsz + j) = exyz.type(j);
//                     }
//                     oldsz = exyz.size();
//                     exyz.resize(oldsz + sz);
//                     for (int j=0; j<sz; j++)
//                     {
//                         exyz.pos(oldsz + j) = exyz.pos(j) - v3*i;
//                         exyz.type(oldsz + j) = exyz.type(j);
//                     }
//                 }

//             }
            
//             for (int i : nbhs)
//             {
//                 Vector3 pos(exyz.pos(i));
//                 Configuration nbh;
//                 nbh.resize(exyz.size() + 1);
//                 nbh.pos(nbh.size()-1) = exyz.pos(i);
//                 nbh.type(nbh.size()-1) = exyz.type(i);
                
//                 for (int j=0; j<exyz.size(); j++)
//                     if (distance(exyz.pos(i), exyz.pos(j)) <= cutoff)
//                     {
//                         nbh.resize(exyz.size() + 1);
//                         nbh.pos(nbh.size()-1) = exyz.pos(j);
//                         nbh.type(nbh.size()-1) = exyz.type(j);
//                     } 
                    
//                 nbh.AppendToFile(args[1]);
//             }
// */
//         }
        
// /*
//         double rcut  = 9;
//         if (!opts["cutoff"].empty())
//             rcut = stod(opts["cutoff"]);

//         double save_additional_atoms = false;

//         ifstream ifs(args[0]);
//         ofstream ofs(args[1]);

//         Configuration nbh;

//         while (nbh.Load(ifs)) {

//             double max_grade = 0;
//             int max_idx = 0;

//             for (int i = 0; i < nbh.size(); i++) {
//                 if (max_grade < nbh.nbh_grades(i)) {
//                     max_grade = nbh.nbh_grades(i);
//                     max_idx = i;
//                 }
//             }

//             Configuration exyz;
//             vector<Vector3> pos_not_deleted;
//             vector<int> type_not_deleted;
//             vector<Vector3> pos_deleted;
//             vector<int> type_deleted;

//             for (int i = 0; i < nbh.size(); i++) {
//                 if (distance(nbh.pos(i), nbh.pos(max_idx)) < rcut) {
//                     pos_not_deleted.push_back(nbh.pos(i));
//                     type_not_deleted.push_back(nbh.type(i));
//                 }
//                 else {
//                     pos_deleted.push_back(nbh.pos(i));
//                     type_deleted.push_back(nbh.type(i));
//                 }
//             }


//             exyz.resize(int(pos_not_deleted.size()+pos_deleted.size()));
//             for (int i = 0; i < pos_not_deleted.size(); i++) {
//                 exyz.pos(i) = pos_not_deleted[i];
//                 exyz.type(i) = type_not_deleted[i];
//             }
//             for (int i = (int)pos_not_deleted.size(); i < pos_deleted.size()+pos_not_deleted.size(); i++) {
//                 exyz.pos(i) = pos_deleted[i-pos_not_deleted.size()];
//                 exyz.type(i) = type_deleted[i-pos_not_deleted.size()];
//             }
//             string neighborhood_info = to_string(pos_not_deleted.size());
//             neighborhood_info += " first atoms are inside the neighborhood within the cut-off radius of ";
//             neighborhood_info += to_string(rcut);
//             neighborhood_info += " angstrom, the rest of the atoms were deleted";
//             exyz.features["Neighborhood_information:"] = neighborhood_info;

//             if (opts["no_save_additional_atoms"] != "") {
//                 exyz.resize(int(pos_not_deleted.size()));
//             }

//             exyz.Save(ofs);

//         }
// */
//     } END_COMMAND;

//     BEGIN_COMMAND("calculate_grade",
//         "calculates extrapolation grade for configurations",
//         "MLP calculate_grade MLP.PhyMLP in.exyz out.exyz [options]:\n"
//         "loads an active learning state from \"MLP.PhyMLP\" and calculates extrapolation grade for configurations from in.exyz.\n"
//         "Configurations with the grades will be written to \"out.exyz\"\n"
//         "and writes them to out.exyz.\n"
//         "  Options:\n"
//         "  --log=<num>: log, default=stdout, output grade for each configuration to this file\n"
//     ) {

//         if (args.size() != 3) {
//             std::cout << "\tError: 3 arguments required\n";
//             return 1;
//         }

//         const string PhyMLP_filename = args[0];
//         const string input_filename = args[1];
//         string output_filename = args[2];

//         cout << "PhyMLPR from " << PhyMLP_filename
//             << ", input: " << input_filename
//             << endl;
//         MLPhyMLPR PhyMLPr(PhyMLP_filename);

//         Settings settings;
//         settings["threshold_save"] = "0";
//         settings["threshold_break"] = "0";
//         settings["log"] = "stdout";
//         settings["add_grade_feature"] = "true";
//         settings["save_extrapolative_to"] = output_filename;
//         settings.Modify(opts);

//         exyzSampling sampler(&PhyMLPr, PhyMLP_filename, settings);

//         Message("Starting grades evaluation");

//         ifstream ifss(input_filename, ios::binary);
//         if (!ifss.is_open())
//             ERROR("Can't open file \"" + input_filename + "\" for reading configurations");

//         int count = 0;
//         for (Configuration exyz; exyz.Load(ifss); count++)
//         {
//             exyz.features["ID"] = to_string(count);
//             if (count % mpi.size == mpi.rank)
//                 sampler.Evaluate(exyz);
//         }

//         ifss.close();
//         if (mpi.rank == 0)
//             Message("Grade evaluation complete");

//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("make_cell_square",
//         "makes the unit cell as square as possible by replicating it",
//         "MLP make_cell_square in.exyz out.exyz\n"
//         "  Options:\n"
//         "  --min_atoms=<int>: minimal number of atoms (default: 32)\n"
//         "  --max_atoms=<int>: maximal number of atoms (default: 64)\n"
//     ) {
//         int min_atoms=32, max_atoms=64;
//         if (opts["min_atoms"] != "") {
//             try { min_atoms = stoi(opts["min_atoms"]); }
//             catch (invalid_argument) {
//                 cerr << (string)"MLP error: " + opts["min_atoms"] + " is not an integer\n";
//             }
//         }
//         if (opts["max_atoms"] != "") {
//             try { max_atoms = stoi(opts["max_atoms"]); }
//             catch (invalid_argument) {
//                 cerr << (string)"MLP error: " + opts["max_atoms"] + " is not an integer\n";
//             }
//         }

//         Configuration exyz;
//         ifstream ifs(args[0], ios::binary);
//         ofstream ofs(args[1], ios::binary);
//         while(exyz.Load(ifs))
//         {
//             int exyz_size = exyz.size();
//             const int M = 4;
//             Matrix3 A, B;
//             Matrix3 L = exyz.lattice * exyz.lattice.transpose();
//             Matrix3 X;
//             double score = 1e99;
//             for (A[0][0] = -M; A[0][0] <= M; A[0][0]++)
//                 for (A[0][1] = -M; A[0][1] <= M; A[0][1]++)
//                     for (A[0][2] = -M; A[0][2] <= M; A[0][2]++)
//                         for (A[1][0] = -M; A[1][0] <= M; A[1][0]++)
//                             for (A[1][1] = -M; A[1][1] <= M; A[1][1]++)
//                                 for (A[1][2] = -M; A[1][2] <= M; A[1][2]++)
//                                     for (A[2][0] = -M; A[2][0] <= M; A[2][0]++)
//                                         for (A[2][1] = -M; A[2][1] <= M; A[2][1]++)
//                                             for (A[2][2] = -M; A[2][2] <= M; A[2][2]++) {
//                                                 if (fabs(A.det()) * exyz_size < min_atoms) continue;
//                                                 if (fabs(A.det()) * exyz_size > max_atoms) continue;
//                                                 X = A*L*A.transpose();
//                                                 double shift = (X[0][0] + X[1][1] + X[2][2]) / 3;
//                                                 X[0][0] -= shift;
//                                                 X[1][1] -= shift;
//                                                 X[2][2] -= shift;
//                                                 double curr_score = X.NormFrobeniusSq();
//                                                 if (curr_score < score) {
//                                                     score = curr_score;
//                                                     B = A;
//                                                 }
//                                             }
//             for (int a = 0; a < 3; a++) {
//                 for (int b = 0; b < 3; b++)
//                     cout << (int)B[a][b] << " ";
//                 cout << "\n";
//             }
//             cout << B.det() << "\n";
//             exyz.ReplicateUnitCell(templateMatrix3<int>((int)B[0][0], (int)B[0][1], (int)B[0][2], (int)B[1][0], (int)B[1][1], (int)B[1][2], (int)B[2][0], (int)B[2][1], (int)B[2][2]));
//             exyz.CorrectSupercell();
//             exyz.Save(ofs);
//         }
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("replicate_cell",
//         "replicates unit cell",
//         "MLP replicate_cell in.exyz out.exyz nx ny nz:\n"
//         "or"
//         "MLP replicate_cell in.exyz out.exyz nxx nxy nxz nyx nyy nyz nzx nzy nzz:\n"
//         "Replicate the supercells by nx*ny*nz.\n"
//         "Alternatively, applies the 3x3 integer matrix to the lattice\n"
//     ) {
//         if (args.size() == 5) {
//             int nx, ny, nz;
//             try { nx = stoi(args[2]); }
//             catch (invalid_argument) {
//                 cerr << (string)"MLP error: " + args[2] + " is not an integer\n";
//             }
//             try { ny = stoi(args[3]); }
//             catch (invalid_argument) {
//                 cerr << (string)"MLP error: " + args[3] + " is not an integer\n";
//             }
//             try { nz = stoi(args[4]); }
//             catch (invalid_argument) {
//                 cerr << (string)"MLP error: " + args[4] + " is not an integer\n";
//             }

//             Configuration exyz;
//             ifstream ifs(args[0], ios::binary);
//             ofstream ofs(args[1], ios::binary);
//             while (exyz.Load(ifs)) {
//                 exyz.ReplicateUnitCell(nx, ny, nz);
//                 exyz.Save(ofs);
//             }
//         } else if (args.size() == 11) {
//             int args_int[3][3];
//             for (int i = 0; i < 9; i++) {
//                 try { args_int[i/3][i%3] = stoi(args[i+2]); }
//                 catch (invalid_argument) {
//                     cerr << (string)"MLP error: " + args[i+2] + " is not an integer\n";
//                 }
//             }
//             templateMatrix3<int> A(args_int);

//             Configuration exyz;
//             ifstream ifs(args[0], ios::binary);
//             ofstream ofs(args[1], ios::binary);
//             while (exyz.Load(ifs)) {
//                 exyz.ReplicateUnitCell(A);
//                 exyz.Save(ofs);
//             }
//         }
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("mindist_filter",
//         "removes the configuration with too short interatomic distance",
//         "MLP mindist_filter input.exyz 2.1 output.exyz:\n"
//     ) {
//         if (args.size() != 3) {
//             cout << "3 arguments are required\n";
//             return 1;
//         }

//         {    ofstream ofs(args[2]);    }

//         auto exyzs = MPI_Loadexyzs(args[0]);
//         double md = stod(args[1]);
//         for (int rnk=0; rnk<mpi.size; rnk++)
//         {
//             MPI_Barrier(mpi.comm);
//             if (rnk == mpi.rank)
//                 for (auto exyz : exyzs)
//                     if (exyz.MinDist() >= md)
//                         exyz.AppendToFile(args[2]);
//         }
//     } END_COMMAND;

//     BEGIN_COMMAND("convert",
//         "converts a file with configurations from one format to another",
//         "MLP convert [options] inputfilename outputfilename\n"
//         "  input filename sould always be entered before output filename\n"
//         "  Options can be given in any order. Options include:\n"
//         "  --input_format=<format>: format of the input file\n"
//         "  --output_format=<format>: format of the output file\n"
// //        "  --input_chgcar=<filename>: name of the chgcar file\n"
// //        "  --input_near_neigh=<filename>: name of the file with nearest neighbor distances\n"
//         "  --append: opens output file in append mode\n"
//         "  --last: ignores all configurations in the input file except the last one\n"
//         "          (useful with relaxation)\n"
//         "  --fix_lattice: creates an equivalent configuration by moving the atoms into\n"
//         "                 the supercell (if they are outside) and tries to make the\n"
//         "                 lattice as much orthogonal as possible and lower triangular\n"
//         "  --save_nonconverged: writes configurations with nonconverged VASP calculations, otherwise they are ignored\n"
//         "  --absolute_types: writes absolute atomic numbers into the exyz file instead of 0,1,2,.... Disabled by default, used only while reading from OUTCAR\n"
//         "  --type_order=18,22,46,... atomic numbers separated with commas in the order as they are in POTCAR. Used only while writing to POSCAR\n"
//         "  --no_forces_stresses: no saving of forces and stresses into the exyz file\n"  
//         "\n"
//         "  <format> can be:\n"
//         "  txt (default):   MLP textual format\n"
// //        "  bin:           MLP binary format\n"
//         "  outcar:          only as input; VASP versions 5.3.5 and 5.4.1 were tested\n"
//         "  poscar:          only as output. When writing multiple configurations,\n"
//         "                   POSCAR0, POSCAR1, etc. are created\n"
//         "  supermd_dump:     only as input. Only lattice, atomic positions and types are saved. Only cartesian coordinates are processed.\n"
//         "  supermd_datafile: only as output. Can be read by read_data from supermd.\n"
//         "                 Multiple configurations are saved to several files.\n"

//         ) {

//         if (opts["input_format"] == "") opts["input_format"] = "txt";
//         if (opts["output_format"] == "") opts["output_format"] = "txt";

//         if (opts["output_format"] == "vasp_outcar" || opts["output_format"] == "outcar" || opts["output_format"] == "supermd_dump")
//             ERROR("Format " + opts["output_format"] + " is not allowed for output");
//         if (opts["input_format"] == "vasp_poscar" || opts["input_format"] == "poscar" || opts["input_format"] == "supermd_datafile")
//             ERROR("Format " + opts["input_format"] + " is not allowed for input");

//         const bool possibly_many_output_files = (opts["output_format"] == "vasp_poscar" || opts["output_format"] == "poscar")
//             || (opts["output_format"] == "supermd_datafile");

//         ifstream ifs(args[0], ios::binary);
//         if (ifs.fail()) ERROR("cannot open " + args[0] + " for reading");

//         ofstream ofs;
//         if (!possibly_many_output_files) {
//             if (opts["append"] == "") {
//                 ofs.open(args[1], ios::binary);
//                 if (ofs.fail()) ERROR("cannot open " + args[1] + " for writing");
//             } else {
//                 ofs.open(args[1], ios::binary | ios::app);
//                 if (ofs.fail()) ERROR("cannot open " + args[1] + " for appending");
//             }
//         }

//         vector<Configuration> db;
//         vector<int> db_species;
//         vector<int> types_mapping;
//         int count = 0;
//         bool read_success = true;

//         // block that reads configurations from VASP OUTCAR into the database
//         if (opts["input_format"] == "vasp_outcar" || opts["input_format"] == "outcar") 
//         {
//             ifs.close();
// 	        Configuration::LoadDynamicsFromOUTCAR(db, args[0],opts["save_nonconverged"] != "",opts["absolute_types"] == "");
//             //to ensure the unified way of POSCAR writing    
//             for (int i=0;i<200;i++)
//                 types_mapping.push_back(i);

//             //block that creates magnetic moments
//             if (opts["input_chgcar"] != "" && opts["input_near_neigh"] != "") {
//                 ifstream ifs_nnd(opts["input_near_neigh"]);
//                 int n_species;
//                 ifs_nnd >> n_species;

//                 Array1D nearest_neigh_dist(n_species);
//                 for (int i = 0; i < n_species; i++) {
//                     ifs_nnd >> nearest_neigh_dist[i];
//                     nearest_neigh_dist[i] /= 4;
//                 }

//                 MagneticMoments MagMom(false, nearest_neigh_dist);
//                 MagMom.LoadDensityFromCHGCAR(opts["input_chgcar"], n_species);
//                 MagMom.CalculateWeights(db[0]);
//                 MagMom.Calculate(db[0]);
//                 if (opts["no_forces_stresses"] != "") {
//                     db[0].has_forces(false);
//                     db[0].has_stresses(false);
//                 }
//             }
//         }

//         //block that reads configurations from supermd dump file into the database
//         bool is_eof_supermd_file = true;
//         if ((opts["input_format"] == "supermd_dump") && (opts["output_format"] != "poscar")) 
//         {
//             while (is_eof_supermd_file) {
//                 Configuration exyz;
//                 is_eof_supermd_file = exyz.LoadNextFromsupermdDump(ifs);
//                 if (is_eof_supermd_file) db.push_back(exyz);
//             }
//         }  

//         Configuration exyz_last; // used to differentiate between single-configuration and multiple-configuration inputs
            
//         //scanning the entire database for all atomic numbers present
//         if ((opts["output_format"] == "vasp_poscar" || opts["output_format"] == "poscar") && ((opts["input_format"] == "txt") || (opts["input_format"] == "bin") || (opts["input_format"] == "") || (opts["input_format"] == "supermd_dump")))
//         {
//             while (read_success)
//             {
//                 Configuration exyz;

//                 // Read exyz
//                 if (db_species.size() == 0) {
//                     if (opts["input_format"] == "txt" || opts["input_format"] == "bin") {
//                         read_success = exyz.Load(ifs);
//                     }
//                     else if (opts["input_format"] == "supermd_dump") {
//                         read_success = exyz.LoadNextFromsupermdDump(ifs);
//                         if (read_success) db.push_back(exyz);
//                     }
//                     else {
//                         ERROR("unknown file format");
//                     }
//                 }
//                 else {
//                     if (opts["input_format"] == "txt" || opts["input_format"] == "bin") {
//                         read_success = exyz.Load(ifs);
//                     }
//                     else if (opts["input_format"] == "supermd_dump") {
//                         read_success = exyz.LoadNextFromsupermdDump(ifs);
//                         if (read_success) db.push_back(exyz);
//                     }
//                 }

//                 for (int i=0; i<exyz.size(); i++)
//                     if (std::find(db_species.begin(), db_species.end(), exyz.type(i)) == db_species.end())
//                         db_species.push_back(exyz.type(i));
//             }

//             //if (std::distance(db_species.begin(), std::max_element(db_species.begin(), db_species.end()))==db_species[db_species.size() - 1])
//             bool relative=true;
//             for (int i=0; i<db_species.size(); i++)
//                 if (std::find(db_species.begin(), db_species.end(), i) == db_species.end())
//                     relative=false;
//             if (relative)
//             {
//                 cout << "relative numeration of species detected" << endl;
//                 for (int i=0; i<db_species.size(); i++)
//                     types_mapping.push_back(i);
//             }
//             else
//             {
//                 cout << "absolute numeration of species detected" << endl;
//                 if (opts["type_order"] == "")
//                 {
//                     std::set<int> tmp;
//                     for (int el : db_species)
//                         tmp.insert(el);
//                     for (int el : tmp)
//                         types_mapping.push_back(el);
//                 }

//                 string t = opts["type_order"];
//                 int k = 0;
//                 while (k<t.size())
//                 {
//                     string type ="";
//                     while ((t[k]!=',')&&(k<t.size()))
//                     {
//                         type+=t[k++];
//                     }
//                     types_mapping.push_back(std::stoi(type));
//                     k+=1;
//                 }

//             }

//             for (int i = 0; i < db_species.size(); i++)
//             {
//                 bool found = false;
//                 for (int j=0; j < types_mapping.size(); j++)
//                     if (db_species[i]==types_mapping[j])
//                         found=true;

//                 if (!found)
//                     ERROR("Not all the species were mentioned in [--type_order] option: " + std::to_string(db_species[i]) + " atomic number is missing.");
//             }
//             ifs.close();
//             ifs.open(args[0], ios::binary);
//         }
        
//         read_success = true;

//         while (read_success) {
//             Configuration exyz;

//             // Read exyz
//             if (db.size() == 0) {
//                 if (opts["input_format"] == "txt" || opts["input_format"] == "bin")
//                     read_success = exyz.Load(ifs);
//                 else
//                 {
//                     Warning("no confgiurations will be saved");
//                     read_success=false;
//                 }
//                     //ERROR("unknown file format");
//             } else {
//                 read_success = (count < db.size());
//                 if (read_success)
//                     exyz = db[count];
//             }
//             if (!read_success) break;

//             if (opts["fix_lattice"] != "") exyz.CorrectSupercell();

//             // Save exyz
//             if (opts["last"] == "") {
//                 if (opts["output_format"] == "txt")
//                     exyz.Save(ofs);
//                 if (opts["output_format"] == "bin")
//                     exyz.SaveBin(ofs);
//                 if (opts["output_format"] == "vasp_poscar" || opts["output_format"] == "poscar") {
//                     if (count != 0) {
//                         if (count == 1) exyz_last.WriteVaspPOSCAR(args[1] + "0",types_mapping);
//                         exyz.WriteVaspPOSCAR(args[1] + to_string(count),types_mapping);
//                     }
//                 }
//                 if (opts["output_format"] == "supermd_datafile") {
//                     if (count != 0) {
//                         if (count == 1) exyz_last.WritesupermdDatafile(args[1] + "0");
//                         exyz.WritesupermdDatafile(args[1] + to_string(count));
//                     }
//                 }
//             }

//             exyz_last = exyz;
//             count++;
//         }
//         if (opts["last"] == "") {
//             if ((opts["output_format"] == "vasp_poscar" || opts["output_format"] == "poscar") && count == 1)
//                 exyz_last.WriteVaspPOSCAR(args[1],types_mapping);
//             if (opts["output_format"] == "supermd_datafile" && count == 1)
//                 exyz_last.WritesupermdDatafile(args[1]);
//         } else {
//             // --last option given
//             if (opts["output_format"] == "txt")
//                 exyz_last.Save(ofs);
//             if (opts["output_format"] == "bin")
//                 exyz_last.SaveBin(ofs);
//             if (opts["output_format"] == "vasp_poscar" || opts["output_format"] == "poscar")
//                 exyz_last.WriteVaspPOSCAR(args[1],types_mapping);
//             if (opts["output_format"] == "supermd_datafile")
//                 exyz_last.WritesupermdDatafile(args[1]);
//         }

//         std::cout << "Processed " << count << " configurations" << std::endl;
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("add_from_outcar",
//         "reads one configuration from the OUTCAR(s)",
//         "MLP add_from_outcar db outcar [outcar2 outcar3 ...]:\n"
//         "reads one configuration from each of the outcars\n"
//         "and APPENDs to the database db\n"
//         ) {

//         if (args.size() < 2) {
//             cout << "MLP add_from_outcar: minimum 2 arguments required\n";
//             return 1;
//         }

//         ofstream ofs(args[0], std::ios::app|std::ios::binary);
//         Configuration exyz;
//         for (int i = 1; i < args.size(); i++) {
//             exyz.LoadFromOUTCAR(args[i],opts["absolute_types"] == "");

// 			if (opts["save_nonconverged"] != "")
// 				exyz.Save(ofs);
// 			else
// 				if (exyz.features["EFS_by"] != "VASP_not_converged")
//             		exyz.Save(ofs);
// 				else
// 					Warning("non-converged OUTCAR detected. Use '--save_noncoverged' option to save it");
//         }
//         ofs.close();
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("add_from_outcar_dyn",
//         "reads dynamics from the OUTCAR(s)",
//         "MLP add_from_outcar_dyn db outcar [outcar2 outcar3 ...]:\n"
//         "reads dynamics configuration from each of the outcars\n"
//         "each configuration from the dynamics is APPENDed to the database\n"
//         ) {

//         if (args.size() < 2) {
//             cout << "MLP add_from_outcar_dyn: minimum 2 arguments required\n";
//             return 1;
//         }

//         ofstream ofs(args[0], ios::app|ios::binary);
//         for (int i = 1; i < args.size(); i++) {
//             vector<Configuration> db;
//             if (!Configuration::LoadDynamicsFromOUTCAR(db, args[i],opts["save_nonconverged"] != "",opts["absolute_types"] == ""))
//                 cerr << "Warning: OUTCAR is broken" << endl;
//             for (Configuration exyz : db)
//                 exyz.Save(ofs);
//         }
//         ofs.close();
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("add_from_outcar_last",
//         "reads the dynamics from OUTCAR(s) and gets the last configuration from each OUTCAR",
//         "MLP add_from_outcar_last db outcar [outcar2 outcar3 ...]:\n"
//         "reads the dynamics from OUTCAR(s) and gets the last configuration from each OUTCAR.\n"
//         "APPENDs all last configurations to the database db\n"
//         ) {

//         if (args.size() < 2) {
//             std::cout << "MLP add_from_outcar: minimum 2 arguments required\n";
//             return 1;
//         }

//         ofstream ofs(args[0], ios::app|ios::binary);
//         Configuration exyz;
//         for (int i = 1; i < args.size(); i++) {
//             if (!exyz.LoadLastFromOUTCAR(args[i],opts["absolute_types"] == ""))
//                 cerr << "Warning: OUTCAR is broken" << endl;
//             exyz.Save(ofs);
//         }
//         ofs.close();
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("to_bin",
//         "converts a database to the binary format",
//         "MLP to_bin db.exyzs db.bin.exyzs:\n"
//         "Reads the database db.exyzs and saves in a binary format to db.bin.exyzs\n"
//         ) {

//         if (args.size() < 3) {
//             cout << "MLP to_bin: minimum 2 arguments required\n";
//             return 1;
//         }

//         ifstream ifs(args[0], ios::binary);
//         ofstream ofs(args[2], ios::binary);
//         Configuration exyz;
//         int count;
//         for (count = 0; exyz.Load(ifs); count++)
//             exyz.SaveBin(ofs);
//         ofs.close();
//         cout << count << " configurations processed.\n";
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("from_bin",
//         "converts a database from the binary format",
//         "MLP from_bin db.bin.exyzs db.exyzs:\n"
//         "Reads the binary database db.bin.exyzs and saves to db.exyzs\n"
//         ) {

//         if (args.size() < 3) {
//             cout << "MLP to_bin: minimum 2 arguments required\n";
//             return 1;
//         }

//         ifstream ifs(args[0], ios::binary);
//         ofstream ofs(args[2], ios::binary);
//         Configuration exyz;
//         int count;

//         for (count = 0; exyz.Load(ifs); count++)
//             exyz.Save(ofs);

//         ofs.close();
//         cout << count << " configurations processed.\n";
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("fix_lattice",
//         "puts the atoms into supercell (if they are outside) and makes lattice as much orthogonal as possible and lower triangular",
//         "MLP fix_lattice in.exyz out.exyz:\n"
//         ) {

//         if (args.size() < 2) {
//             cout << "MLP to_bin: minimum 2 arguments required\n";
//             return 1;
//         }

//         ifstream ifs(args[0], ios::binary);
//         ofstream ofs(args[1], ios::binary);
//         Configuration exyz;
//         int count;
//         for (count = 0; exyz.Load(ifs); count++) {
//             exyz.CorrectSupercell();
//             exyz.Save(ofs);
//         }
//         ofs.close();
//         cout << count << " configurations processed.\n";
//     } END_COMMAND;

//     BEGIN_COMMAND("mindist",
//         "reads a exyz file and saves it with added mindist feature",
//         "MLP mindist db.exyz [Options]\n"
//         "  Options can be given in any order. Options include:\n"
//         "  --no_overwrite=<true/false>: do not change db.exyz, only print global mindist\n"
//         "  --no_types=<true/false>: calculate a single mindist for all types"
//         ) 
//     {

//         if (args.size() != 1) {
//             cout << "MLP mindist: 1 arguments required\n";
//             return 1;
//         }

//         auto exyzs = MPI_Loadexyzs(args[0]);
//         if (exyzs.back().size() == 0)
//             exyzs.pop_back();
//         bool no_overwrite = opts.count("no_overwrite") > 0;
//         bool no_types = opts.count("no_types") > 0;

//         string outfnm = args[0];
//         if (mpi.size > 1)
//             outfnm += mpi.fnm_ending;
//         if (!no_overwrite) { ofstream ofs(outfnm); }

//         map<pair<int, int>, double> global_mindists;
//         double global_md = HUGE_DOUBLE;
//         for (auto& exyz : exyzs)
//         {
//             auto typeset = exyz.GetTypes();
//             auto mdm = exyz.GetTypeMindists();
            
//             double local_md = HUGE_DOUBLE;
//             for (int t1 : typeset)
//                 for (int t2 : typeset)
//                     local_md = __min(local_md, mdm[make_pair(t1, t2)]);
//             global_md = __min(local_md, global_md);

//             for (auto& md : mdm)
//                 if (global_mindists.find(md.first) != global_mindists.end())
//                     global_mindists[md.first] = __min(md.second, global_mindists[md.first]);
//                 else
//                     global_mindists[md.first] = md.second;

//             if (!no_overwrite)
//             {
//                 if (!no_types)
//                 {
//                     string str = "{";
//                     for (auto& md : mdm)
//                         if (md.first.first <= md.first.second)
//                             str += "(" + to_string(md.first.first) + "," + to_string(md.first.second) + "):" + to_string(md.second) + ",";
//                     str = str.substr(0, str.length()-1);
//                     exyz.features["mindists"] = str + '}';
//                     exyz.AppendToFile(outfnm);
//                 }
//                 else
//                 {
//                     exyz.features["mindists"] = to_string(local_md);
//                     exyz.AppendToFile(outfnm);
//                 }
//             }
//         }

//         if (mpi.rank == 0)
//         {
//             cout << "Global mindist: " << global_md << endl;
//             for (auto& md : global_mindists)
//                 if (md.first.first <= md.first.second)
//                     cout << "mindist(" << md.first.first << ", " << md.first.second << ") = " << md.second << endl;
//         }
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("fix_mindist",
//         "fixes too short minimal interatomic distance in all configurations from a file by relaxation with repulsive pair PES",
//         "MLP fix_mindist input.exyz output.exyz 1.6 [Options]\n"
//         "the third argument is new minimal allowed interatomic distance\n"
//         "Options:\n"
//         "   --correct_cell=<true/false>: orthogonolize supercell "
//     ) {

//         if (args.size() != 3) ERROR("MLP fix_mindist: 3 arguments required\n");

//         Settings settings;
//         settings["init_mindist"] = args[2];
//         settings["iteration_limit"] = "0";
//         if (!opts["log"].empty())
//             settings["log"] = opts["log"];
//         settings["correct_cell"] = opts["correct_cell"];

//         Relaxation rlx(settings);

//         ifstream ifs(args[0], ios::binary);
//         ofstream ofs(args[1] + mpi.fnm_ending, ios::binary);

//         if (!ifs.is_open()) ERROR("input file is not open");
//         if (!ofs.is_open()) ERROR("output file is not open");

//         int count=0;
//         for (Configuration exyz; exyz.Load(ifs); count++)
//             if (count%mpi.size == mpi.rank)
//             {
//                 if (exyz.size() != 0)
//                 {
//                     rlx.exyz = exyz;

//                     try { rlx.Run(); }
//                     catch (MLPException& e) 
//                     {
//                         Warning("Mindist fixing in exyz#"+to_string(count+1)+" failed: "+e.message);
//                     }

//                     rlx.exyz.Save(ofs);
//                 }
//             }
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("subsample",
//         "subsamples a database (reduces size by skiping every N configurations)",
//         "MLP subsample db_in.exyz db_out.exyz skipN\n"
//         ) {

//         if (args.size() != 3) {
//             cout << "MLP subsample: 3 arguments required\n";
//             return 1;
//         }

//         ifstream ifs(args[0], ios::binary);
//         ofstream ofs(args[1], ios::binary);
//         Configuration exyz;
//         int skipN = stoi(args[2]);
//         for (int i = 0; exyz.Load(ifs); i++) {
//             if (i % skipN == 0)
//                 exyz.Save(ofs);
//         }
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("fix_exyz",
//         "Fixes a database by reading and writing it again",
//         "MLP fix_db db.exyz [options]\n"
//         "  Options:\n"
//         "  --no_loss: writes a file with a very high precision\n"
//     ) {
//         unsigned int flag = 0U;
//         if (opts["no_loss"] != "")
//             flag |= Configuration::SAVE_NO_LOSS;

//         std::vector<Configuration> db;
//         {
//             Configuration exyz;
//             std::ifstream ifs(args[0], std::ios::binary);
//             while (exyz.Load(ifs)) {
//                     db.push_back(exyz);
//             }
//             ifs.close();
//         }
//         {
//             Configuration exyz;
//             std::ofstream ofs(args[0], std::ios::binary);
//             for (int i = 0; i < db.size(); i++) {
//                 db[i].Save(ofs, flag);
//             }
//             ofs.close();
//         }
//     }
//     END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("filter_nonconv",
//         "removes configurations with feature[EFS_by] containing not_converged",
//         "MLP filter_nonconv db.exyz\n"
//         ) {
//         if (args.size() != 1) {
//         std::cerr << "Error: 1 argument required" << std::endl;
//         std::cerr << "Usage: MLP filter_nonconv db.exyz" << std::endl;
//         return 1;
//     }
//     std::vector<Configuration> db;
//     {
//         Configuration exyz;
//         std::ifstream ifs(args[0], std::ios::binary);
//         while (exyz.Load(ifs)) {
//             if (exyz.features["EFS_by"].find("not_converged") == std::string::npos)
//                 db.push_back(exyz);
//         }
//         ifs.close();
//     }
//     {
//         Configuration exyz;
//         std::ofstream ofs(args[0], std::ios::binary);
//         for (int i = 0; i < db.size(); i++) {
//             db[i].Save(ofs);
//         }
//         ofs.close();
//     }
//     } END_COMMAND;

//     BEGIN_COMMAND("test",
//         "performs a number of unit tests",
//         "MLP test\n"
//     ) {
//         if(!self_test()) exit(1);
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("remap_species",
//         "changes species numbering",
//         "MLP remap_species in.exyz out.exyz n0 n1 ...\n"
//     ) {
//         if (args.size() <= 3) {
//             std::cout << "\tError: at least 3 arguments required\n";
//             return 1;
//         }

//         vector<int> new_species;
//         for(int i=2; i < args.size(); i++)
//             new_species.push_back(std::stoi(args[i]));

//         ifstream ifs(args[0], std::ios::binary);
//         ofstream ofs(args[1], std::ios::binary);
//         Configuration exyz;
//         while (exyz.Load(ifs)) {
//             for(int i=0; i<exyz.size(); i++)
//                 exyz.type(i) = new_species[exyz.type(i)];
//             exyz.Save(ofs);
//         }
//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("extract_nbhs",
//         "Creates small configurations from a large ones by extracting neighborhoods encoded in features (\"nbhs_inds_to_extract\")",
//         "MLP extract_nbhs large.exyz nbhs.exyz\n"
//         "neighborhood index numeration starts with 1\n"
//         "Options:\n"
//         "   --lattice=<double>,<double>,<double>,<double>,<double>,<double>,<double>,<double>,<double>\n"
//         "   --cutoff=<double>\n"
//         "   --mindist=<double>/<string>"
//     ) {
//         if (args.size() != 2) {
//             std::cout << "\tError: 2 arguments required\n";
//             return 1;
//         }

//         Message("Initialization");

//         const string inp_filename = args[0];
//         const string out_filename = args[1];

//         double cutoff = 5.0;
//         bool change_cutoff = false;
//         if (!opts["cutoff"].empty())
//             cutoff = stod(opts["cutoff"]);

//         if (!opts["lattice"].empty())
//             change_cutoff = true;

//         string lat_str = (opts["lattice"].empty()) ?
//             to_string(2*cutoff) + ",0.0,0.0,0.0," + to_string(2*cutoff) + ",0.0,0.0,0.0," + to_string(2*cutoff) :
//             opts["lattice"];

//         Matrix3 lattice;
//         for (int i=0; i<8; i++)
//         {
//             lattice[i/3][i%3] = stod(lat_str.substr(0, lat_str.find(',')));
//             lat_str = lat_str.substr(lat_str.find(',')+1);
//         }
//         lattice[2][2] = stod(lat_str);

//         if (change_cutoff)
//         {
//             cutoff = Vector3(lattice[0][0], lattice[0][1], lattice[0][2]).Norm()/2;
//             cutoff = min(cutoff, Vector3(lattice[1][0], lattice[1][1], lattice[1][2]).Norm()/2);
//             cutoff = min(cutoff, Vector3(lattice[2][0], lattice[2][1], lattice[2][2]).Norm()/2);
//         }

//         vector<Configuration> nbhexyzs;

//         Settings settings;
//         settings["init_mindist"] = opts["mindist"];
//         settings["iteration_limit"] = "0";
//         settings["use_gd_method"] = "true";
//         settings["log"] = "stdout";

//         Relaxation rlx(settings);

//         ifstream ifs(inp_filename, ios::binary);
//         int cntr = 1;
//         for (Configuration exyz; exyz.Load(ifs); cntr++)
//         {
//             int nbh_cntr = 0;
//             if (exyz.features["nbhs_inds_to_extract"].empty())
//                 ERROR("\"nbhs_inds_to_extract\" feature not found in exyz#" + to_string(cntr));
//             string inds_string = exyz.features["nbhs_inds_to_extract"];

//             while (!inds_string.empty())
//             {
//                 int ind = -1;
//                 auto comma_pos = inds_string.find(',');
//                 if (comma_pos != string::npos)
//                 {
//                     ind = stoi(inds_string.substr(0, comma_pos+1));
//                     inds_string = inds_string.substr(comma_pos+1);
//                 }
//                 else
//                 {
//                     ind = stoi(inds_string);
//                     inds_string.clear();
//                 }
//                 ind--;
//                 //ind -= 1 - 3*(exyz.size()-exyz.ghost_inds.size()) - 9;

//                 nbhexyzs.push_back(exyz.GetexyzFromLocalEnv(ind, lattice));
//                 nbh_cntr++;

//                 if (!opts["mindist"].empty())
//                 {
//                     Configuration& extracted_exyz = nbhexyzs.back();

//                     set<int> fixed_inds;

//                     fixed_inds.insert(0);
//                     extracted_exyz.InitNbhs(cutoff);
//                     for (int i=0; i<extracted_exyz.nbhs[0].count; i++)
//                         fixed_inds.insert(extracted_exyz.nbhs[0].inds[i]);

//                     // check the minimal distance between fixed atoms
//                     {
//                         Configuration exyz_tmp;
//                         for (int i : fixed_inds)
//                         {
//                             exyz_tmp.resize(exyz_tmp.size()+1);
//                             exyz_tmp.pos(exyz_tmp.size()-1) = extracted_exyz.pos(i);
//                             exyz_tmp.type(exyz_tmp.size()-1) = extracted_exyz.type(i);
//                         }

//                         if (opts["mindist"].find(':') != string::npos)
//                         {
//                             auto typeset = exyz.GetTypes();
//                             auto md_map = exyz_tmp.GetTypeMindists();
//                             std::map<int, double> mindist_cores;

//                             string mindist_string = opts["mindist"];
//                             mindist_string = mindist_string.substr(1);
//                             while (!mindist_string.empty())
//                             {
//                                 int endpos = (int)mindist_string.find(':', 0);
//                                 int spec = stoi(mindist_string.substr(0, endpos));
//                                 mindist_string = mindist_string.substr(endpos+1);
//                                 if ((endpos = (int)mindist_string.find(',', 0)) != -1)
//                                 {
//                                     double rad = stod(mindist_string.substr(0, endpos));
//                                     mindist_string = mindist_string.substr(endpos+1);
//                                     mindist_cores[spec] = rad;
//                                 }
//                                 else if ((endpos = (int)mindist_string.find('}', 0)) != -1)
//                                 {
//                                     double rad = stod(mindist_string.substr(0, endpos));
//                                     mindist_cores[spec] = rad;
//                                     break;
//                                 }
//                                 else
//                                     ERROR("Incorrect setting for\'mindist\'");
//                             }

//                             double delta = HUGE_DOUBLE;
//                             for (int i : typeset)
//                                 for (int j : typeset)
//                                     delta = min(delta, md_map[make_pair(i, j)] - (mindist_cores[i]+mindist_cores[j]));

//                             if (delta < 0)
//                             {
//                                 Warning("Neighborhood mindist is smaller than the target mindist!");
//                                 continue;
//                             }
//                         }
//                         else
//                         {
//                             double mindist = stod(opts["mindist"]);
//                             if (mindist > exyz_tmp.MinDist())
//                             {
//                                 Warning("Neighborhood mindist (" 
//                                         + to_string(exyz_tmp.MinDist()) 
//                                         + ") is smaller than target mindist (" 
//                                         + to_string(mindist) 
//                                         + ")!");
//                                 continue;
//                             }
//                         }
//                     }

//                     for (int i : fixed_inds)
//                         extracted_exyz.features["relax:fixed_atoms"] += to_string(i) + ",";
//                     extracted_exyz.features["relax:fixed_atoms"].resize(extracted_exyz.features["relax:fixed_atoms"].size()-1);

//                     rlx.exyz = extracted_exyz;

//                     double mindist = rlx.exyz.MinDist();
//                     double target_mindist = stod(opts["mindist"]);
//                     while (mindist < target_mindist)
//                     {
//                         try { rlx.Run(); }
//                         catch (MLPException& e) { Warning("Mindist correction failed: " + e.message); }
//                         for (int i=0; i<extracted_exyz.size(); i++)
//                             if (fixed_inds.count(i) > 0)
//                                 rlx.exyz.pos(i) = extracted_exyz.pos(i);
//                         mindist = rlx.exyz.MinDist();
//                     }

//                     extracted_exyz = rlx.exyz;
//                 }
//             }
//             cout << "from configuration #" << cntr << " extracted " << nbh_cntr << " configuration(s)" << endl;
//         }

//         { ofstream ofs(out_filename); }
//         for (int i=0; i<mpi.size; i++)
//         {
//             if (i == mpi.rank)
//             {
//                 ofstream ofs(args[1], ios::binary | ios::app);
//                 for (auto& exyz : nbhexyzs)
//                     exyz.Save(ofs);
//             }
//             MPI_Barrier(mpi.comm);
//         }

//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("invert_stress",
//         "xxx",
//         "MLP invert_stress input.exyz:\n"
//     ) {

//         if (args.size() != 1) {
//             std::cout << "\tError: 1 arguments required\n";
//             return 1;
//         }

//         const string exyz_filename = args[0];

//         auto exyzs = Loadexyzs(exyz_filename);
        
//         { ofstream ofs(exyz_filename); }

//         int counter=0;
//         for (auto exyz : exyzs)
//         {
//             exyz.stresses *= -1;
//             exyz.AppendToFile(exyz_filename);
//             cout << ++counter << endl;
//         }

//     } END_COMMAND;

//     BEGIN_UNDOCUMENTED_COMMAND("recognize",
//         "XXX",
//         "MLP recognize PhyMLP100.PhyMLP input.exyz --train=out.mvs:\n"
//     ) 
//     {
//         if (args.size() != 2) {
//             std::cout << "\tError: 2 arguments required\n";
//             return 1;
//         }

//         const string PhyMLP_filename = args[0];
//         const string exyz_filename = args[1];

//         PhyMLP PhyMLP(PhyMLP_filename);

//         if (!opts["train"].empty())
//         {
//             Settings set;
//             set["site_en_weight"] = "1";
//             set["energy_weight"] = "0";
//             set["force_weight"] = "0";
//             set["stress_weight"] = "0";
//             set["weight_scaling"] = "0";
                
//             exyzSelection selector(&PhyMLP, set);

//             selector.LoadSelected(args[1]);

//             selector.Save(opts["train"]);
//         }
//         else
//         {
//             auto exyzs = MPI_Loadexyzs(args[1]);

//             for (auto& exyz : exyzs)
//                 for (int i=0; i< exyz.size(); i++)
//                     exyz.type(i) = 0;
            
//             Settings set;
//             set["threshold_save"] = "1.";
//             set["threshold_break"] = "0";
//             set["save_extrapolative_to"] = "";
//             set["add_grade_feature"] = "true";
//             set["log"] = "stdout";

//             exyzSampling samp(&PhyMLP, PhyMLP_filename, set);

//             ofstream ofs("recognition.txt");

//             int cntr = 0;
//             for (auto& exyz : exyzs)
//             {
//                 samp.Grade(exyz);

//                 // find two atoms with maximal grades
//                 int i1=-1, i2=-1;
//                 double g1=-1, g2=-1;
//                 for (int i=0; i<exyz.size(); i++)
//                     if (exyz.nbh_grades(i) > g1)
//                     {
//                         i1 = i;
//                         g1 = exyz.nbh_grades(i);
//                     }
//                 for (int i=0; i<exyz.size(); i++)
//                     if (exyz.nbh_grades(i) > g2 && i != i1)
//                     {
//                         i2 = i;
//                         g2 = exyz.nbh_grades(i);
//                     }

//                 //
//                 bool high_grades = false;
//                 for (int i=0; i<exyz.size(); i++)
//                     if (exyz.nbh_grades(i) > g2/5.0 && i!=i1 && i!=i2)
//                         high_grades = true;
//                 bool low_grades = false;
//                 if (g2 < 11.0)
//                     low_grades = true;

//                 //
//                 Vector3 l1(exyz.lattice[0][0], exyz.lattice[0][1], exyz.lattice[0][2]);
//                 Vector3 l2(exyz.lattice[1][0], exyz.lattice[1][1], exyz.lattice[1][2]);
//                 Vector3 l3(exyz.lattice[2][0], exyz.lattice[2][1], exyz.lattice[2][2]);
//                 bool is_lattice_ortog = (fabs(l1*l2) + fabs(l2*l3) + fabs(l1*l3) < 0.1);
//                 double a = (l1.Norm() + l2.Norm() + l3.Norm()) / 3/4;
//                 //cout << " lat_dist=" << a << ' ';
//                 bool is_lattice_cubic = ((l1-l2).Norm() + (l2-l3).Norm() + (l1-l3).Norm() < 0.1*a);
//                 //
//                 Vector3 d12 = exyz.pos(i1) - exyz.pos(i2);
//                 bool wrong_orientation = false;
//                 bool wrong_dist = false;
//                 if (d12.Norm() < 0.85*1.45*sqrt(2)*a/3 || d12.Norm() > 1.15*1.45*sqrt(2)*a/3)
//                     wrong_dist = true;
//                 //cout << ' ' << d12.Norm() << ' ' << sqrt(2)*a/3 << ' ' << d12.Norm()/(sqrt(2)*a/3) << ' ';
//                 if (fabs(d12*Vector3(1,1,0)) < 0.9)
//                     wrong_orientation = true;

//                 bool shifted = false;
//                 if (exyz.pos(i1, 0) < 0.05*a ||
//                     exyz.pos(i1, 1) < 0.05*a ||
//                     exyz.pos(i1, 2) < 0.4*a  ||
//                     exyz.pos(i1, 0) > 0.95*a ||
//                     exyz.pos(i1, 1) > 0.95*a ||
//                     exyz.pos(i1, 2) > 0.6*a  ||
//                     exyz.pos(i2, 0) < 0.05*a ||
//                     exyz.pos(i2, 1) < 0.05*a ||
//                     exyz.pos(i2, 2) < 0.4*a  ||
//                     exyz.pos(i2, 0) > 0.95*a ||
//                     exyz.pos(i2, 1) > 0.95*a ||
//                     exyz.pos(i2, 2) > 0.6*a)
//                     shifted = true;

//                 ofs << "exyz# " << ++cntr 
//                     << "\ni1= " << i1 << " g1=" << g1 << "\ti2= " << i2  << " g2=" << g2
//                     << "\nhigh_grades_check " << high_grades
//                     << "\nlow_grades_check " << low_grades
//                     << "\nlattice_ortogonality_check " << is_lattice_ortog
//                     << "\nlattice_cubic_check " << is_lattice_cubic
//                     << "\nwrong_orientation_check " << wrong_orientation
//                     << "\nwrong_distance_check " << wrong_dist
//                     << "\ndisplscement_check " << shifted
//                     << "\n"
//                     << endl;

//             }
//         }

//     } END_COMMAND;

    return is_command_found;
}
