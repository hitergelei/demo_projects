/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   Contributors: Evgeny Podryabinkin
 */

#ifndef MLP_EXTERNAL_PES_INTERFACE_H
#define MLP_EXTERNAL_PES_INTERFACE_H


#include "basic_PES.h"


 // class allows one to use PES embedded in LAMMPS. It is implemented via files exchange with LAMMPS that should be launched by MLP for EFS calculation
class ExternalPES : public AnyPES, protected InitBySettings
{
public:
    const int io_max_attemps = 5; // number of attempts to read/write files 

    std::string input_filename = "";   // input filename for external PES with configuration 
    std::string output_filename = "";  // output filename for external PES with configuration 
    std::string start_command = "";    // command to OS environment launching external PES

    void InitSettings()           // Sets correspondence between variables and setting names in settings file
    {
        MakeSetting(input_filename, "input_file");
        MakeSetting(output_filename, "output_file");
        MakeSetting(start_command, "start_command");
    }

    ExternalPES(const Settings& settings)
    {
        InitSettings();
        ApplySettings(settings);
        PrintSettings();
        if ((input_filename == "") || (output_filename == "") || (start_command == "")) {
            ERROR("No input file name, or output file name or launch commad provided!");
        }
    }
    /*ExternalPES(   const std::string& _input_filename,
                        const std::string& _output_filename,
                        const std::string& _start_command) :
                        input_filename(_input_filename),
                        output_filename(_output_filename),
                        start_command(_start_command) 
    {}*/

    bool CheckexyzNotChanged(Configuration& exyz_vrf, Configuration& exyz, std::string="Error.exyz");
    void CopyEFS(Configuration & from, Configuration & to);
    void CalcEFS(Configuration& conf);
};

#endif //#ifndef MLP_EXTERNAL_PES_INTERFACE_H

