/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   Contributors: Evgeny Podryabinkin
 */


#include "external_PES.h"


using namespace std;


bool ExternalPES::CheckexyzNotChanged(Configuration& exyz_vrf, Configuration& exyz, string err_fnm)
{
    bool answer = true;

    if (norm(exyz.lattice - exyz_vrf.lattice) > 1.0e-4)
    {
        exyz_vrf.AppendToFile(err_fnm + "_inp");
        exyz.AppendToFile(err_fnm + "_out");
        Warning("Lattice changed after EFS calculation!");
        answer &= false;
    }
    if (exyz.size() != exyz_vrf.size())
    {
        exyz_vrf.AppendToFile(err_fnm + "_inp");
        exyz.AppendToFile(err_fnm + "_out");
        Warning("Atoms count changed after EFS calculation!");
        answer &= false;
    }
    for (int i=0; i<exyz.size(); i++)
    {
        Vector3 shift((exyz_vrf.pos(i) - exyz.pos(i)) * exyz_vrf.lattice.inverse());   // shift must has components close to 0 or 1
        if ((fabs(shift[0]) > 1.0e-4 && fabs(shift[0])-1.0 > 1.0e-4) ||
            (fabs(shift[1]) > 1.0e-4 && fabs(shift[1])-1.0 > 1.0e-4) ||
            (fabs(shift[2]) > 1.0e-4 && fabs(shift[2])-1.0 > 1.0e-4))
        {
            exyz_vrf.AppendToFile(err_fnm + "_inp");
            exyz.AppendToFile(err_fnm + "_out");
            Warning("Position of atom#" + to_string(i+1) + " changed after EFS calculation!");
            answer &= false;
        }
    }
    for (int i=0; i<exyz.size(); i++)
    {
        if (exyz_vrf.type(i) != exyz.type(i))
        {
            exyz_vrf.AppendToFile(err_fnm + "_inp");
            exyz.AppendToFile(err_fnm + "_out");
            Warning("Type of atom#" + to_string(i+1) + " changed after EFS calculation!");
            answer &= false;
        }
    }

    return answer;
}

void ExternalPES::CopyEFS(Configuration & from, Configuration & to)// Copying EFS data from one configuration to another
{
    to.has_energy(from.has_energy());
    to.has_forces(from.has_forces());
    to.has_stresses(from.has_stresses());
    to.has_site_energies(from.has_site_energies());

    if (from.size() != to.size())
    {
        to.resize(from.size());
        memcpy(&to.pos(0), &from.pos(0), from.size() * sizeof(Vector3));
    }

    if (from.has_forces())
        memcpy(&to.force(0, 0), &from.force(0, 0), from.size() * sizeof(Vector3));
    if (from.has_stresses())
        to.stresses = from.stresses;
    if (from.has_energy())
        to.energy = from.energy;
    if (from.has_site_energies())
        memcpy(&to.site_energy(0), &from.site_energy(0), from.size() * sizeof(double));

    if (from.features.count("EFS_by") > 0)
        to.features["EFS_by"] = from.features["EFS_by"];
}

void ExternalPES::CalcEFS(Configuration & conf)
{

    Configuration& exyz = conf;

    //save configuration to input file
    ofstream ofs(input_filename, ios::binary);
    exyz.Save(ofs);

    // starting external PES
    int res = system(start_command.c_str());
    if (res != 0)
        Message("External PES exits with code " + to_string(res));

    //load configuration from output file
    ifstream ifs(output_filename, ios::binary);
    exyz.Load(ifs);

#ifdef MLP_DEBUG
        if (!CheckexyzNotChanged(exyz, conf)) 
            ERROR("Configuration changed after calculation on abinitio model");
#endif

    CopyEFS(conf, exyz);
}
