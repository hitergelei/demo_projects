/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   Contributors: Evgeny Podryabinkin
 */


#include "lammps_PES.h"


using namespace std;


void lammps_PES::CalcEFS(Configuration & conf)
{
    Matrix3 Q;
    Matrix3 L;
    Configuration exyz = conf;

    exyz.lattice.transpose().QRdecomp(Q, L);
    exyz.Deform(Q);

    ofstream ofs(input_filename.c_str());

    ofs.precision(16); ofs.setf(ios::scientific);

    ofs << "ITEM: TIMESTEP \n"
        << "0\n"
        << "ITEM: NUMBER OF ATOMS \n"
        << exyz.size() << '\n'
        << "ITEM: BOX BOUNDS xy xz yz pp pp pp \n"
        << 0 <<' '<< exyz.lattice[0][0] + exyz.lattice[1][0] + exyz.lattice[2][0] <<' '<< exyz.lattice[1][0] << '\n'
        << 0 <<' '<< exyz.lattice[1][1] + exyz.lattice[2][1] <<' '<< exyz.lattice[2][0] << '\n'
        << 0 <<' '<< exyz.lattice[2][2] <<' '<< exyz.lattice[2][1] << '\n'
        << "ITEM: ATOMS id x y z \n";
    for (int i=0; i<exyz.size(); i++)
        ofs << i+1 << ' '
            << exyz.pos(i, 0) << ' '
            << exyz.pos(i, 1) << ' '
            << exyz.pos(i, 2) << " \n";
    ofs.close();

    // starting lammps
    int res = system(("rm " + output_filename).c_str());
    res = system(start_command.c_str());
    if (res != 0)
        Message("lammps exits with code " + to_string(res));

    //try
    //{
    ifstream ifs(output_filename);
    if (!ifs.is_open())
        ERROR("Can't open file " + output_filename);

    int foo;
    char buff[999];
    ifs.getline(buff, 999, '\n');
    if (strcmp(buff, "ITEM: TIMESTEP"))
        ERROR("Invalid file format. \"ITEM: TIMESTEP\" not fount");
    ifs >> foo;
    if (foo != 0)
        ERROR("TIMESTEP should be 0");
    ifs.ignore(99999, '\n');

    ifs.getline(buff, 999, '\n');
    if (strcmp(buff, "ITEM: NUMBER OF ATOMS"))
        ERROR("Invalid file format. \"ITEM: NUMBER OF ATOMS\" not fount");
    ifs >> foo;
    if (foo != exyz.size())
        ERROR("Atoms count changed after lammps calculation");
    ifs.ignore(99999, '\n');

    ifs.getline(buff, 999, '\n');
    if (strcmp(buff, "ITEM: BOX BOUNDS xy xz yz pp pp pp"))
        ERROR("Invalid file format. \"ITEM: BOX BOUNDS xy xz yz pp pp pp\" not fount");
    double bar;
    ifs >> bar >> exyz.lattice[0][0] >> exyz.lattice[1][0];
    exyz.lattice[0][0] -= bar;
    ifs >> bar >> exyz.lattice[1][1] >> exyz.lattice[2][0];
    exyz.lattice[1][1] -= bar;
    ifs >> bar >> exyz.lattice[2][2] >> exyz.lattice[2][1];
    exyz.lattice[2][2] -= bar;
    exyz.lattice[0][0] -= exyz.lattice[1][0] + exyz.lattice[2][0];
    exyz.lattice[1][1] -= exyz.lattice[2][1];
    ifs.ignore(99999, '\n');

    ifs.getline(buff, 999, '\n');
    if (strcmp(buff, "ITEM: ATOMS id x y z fx fy fz "))
        ERROR("Invalid file format. \"ITEM: ATOMS id x y z fx fy fz \" not fount");
    exyz.has_forces(true);
    for (int i=0; i<exyz.size(); i++)
        ifs >> foo
        >> exyz.pos(i, 0) >> exyz.pos(i, 1) >> exyz.pos(i, 2)
        >> exyz.force(i, 0) >> exyz.force(i, 1) >> exyz.force(i, 2);
    ifs.ignore(99999, '\n');

    ifs.getline(buff, 999, '\n');
    if (strcmp(buff, "ITEM: ENERGY"))
        ERROR("Invalid file format. \"ITEM: ENERGY\" not fount");
    exyz.has_energy(true);
    ifs >> exyz.energy;
    ifs.ignore(99999, '\n');

    ifs.getline(buff, 999, '\n');
    if (!ifs.eof() && !strcmp(buff, "ITEM: STRESSES xx yy zz xy xz yz"))
    {
        exyz.has_stresses(true);
        ifs >> exyz.stresses[0][0] >> exyz.stresses[1][1] >> exyz.stresses[2][2]
            >> exyz.stresses[0][1] >> exyz.stresses[0][2] >> exyz.stresses[1][2];

        exyz.stresses[1][0] = exyz.stresses[0][1];
        exyz.stresses[2][0] = exyz.stresses[0][2];
        exyz.stresses[2][1] = exyz.stresses[1][2];

        exyz.stresses *= fabs(exyz.lattice.det()) * 0.0001 / 160.2176487;
    }

    ifs.close();
    //}
    //catch (MLPException& excp)
    //{
    //  Message(excp.What());
    //  ERROR("lammps output file reading failed");
    //}

    exyz.Deform(Q.transpose());

    if (exyz.has_forces())
        for (int i=0; i<exyz.size(); i++)
            exyz.force(i) = exyz.force(i) * Q;

    if (exyz.has_stresses())
        exyz.stresses = Q.transpose() * exyz.stresses * Q;

    conf = exyz;

    conf.features["EFS_by"] = "lammps";
}
