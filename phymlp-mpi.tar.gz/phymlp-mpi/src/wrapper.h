/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   Contributors: Evgeny Podryabinkin
 */

#ifndef MLP_WRAPPER_H
#define MLP_WRAPPER_H



#include "error_monitor.h"
#include "basic_MLP.h"
#include "external_PES.h"

// // Class that allows working with MLP in multiple regimes (e.g. fitting, EFS calculating, active learning, fitting error calculation, etc.)
class Wrapper : protected InitBySettings //, public LogWriting
{
  protected:
  static const char* tagname;                           // tag name of object
  private:
    // settings initialized by default values
    std::string MLP_type = "";             // MLP type
    std::string MLP_fnm = "";              // file name, MLP will be loaded from. MLP is not required if empty
    bool enable_MLP = false;
    bool enable_EFScalc = false;            // if true MLP will calculate EFS
    bool enable_sampling = false;           // turns sampling on of true
    bool enable_select = false;             // turns selection on of true
    bool enable_learn = false;              // if true MLP fitting will be performed
    bool enable_lotf = false;
    bool enable_exyz_writing = false;
    bool enable_err_check = false;

    bool efs_ignored = false;               // if efs ignored by driver it is possible to speed up some scenarios
    std::string exyzs_fnm = "";              // filename for recording configurations (calculated by CalcEFS()). No configurations are recorded if empty
    int skip_saving_N_exyzs = 0;             // every skip_saving_N_exyzs+1 configuration will be saved (see previous option)
    std::string log_output = "";            // filename or "stdout" or "stderr" for this object log output. No logging if empty
    bool enable_abinitio = false;           // if true MLP will use external PES for calculations 

    Configuration exyz_valid;                // temporal for errmon

    int call_count = 0;                     // number of processed exyz
    int learn_count = 0;                    // number of learned exyz
    int PhyMLP_count = 0;                      // number of PhyMLP calcs
    int abinitio_count = 0;                 // number of abinitio calcs

    void InitSettings()                        // Sets correspondence between variables and setting names in settings file
    {
        MakeSetting(enable_MLP,            "MLP");                 
        MakeSetting(MLP_fnm,               "MLP:load_from");       
        MakeSetting(enable_EFScalc,         "calculate_efs");        
        MakeSetting(enable_learn,           "fit");                  
        MakeSetting(enable_sampling,        "extrapolation_control");
        MakeSetting(enable_select,          "select");
        MakeSetting(enable_lotf,            "lotf");
        MakeSetting(enable_exyz_writing,     "write_exyzs");
        MakeSetting(exyzs_fnm,               "write_exyzs:to");
        MakeSetting(skip_saving_N_exyzs,     "write_exyzs:skip");
        MakeSetting(enable_err_check,       "check_errors");
        MakeSetting(enable_abinitio,        "abinitio");                  
    };
    void SetUpMLP(const Settings&);    // Initialize object state according to settings

  public:
    // AnyPES* p_abinitio = nullptr;        // pointer to abinitio PES
    ExternalPES* p_external = nullptr;
    AnyLocalMLP* p_MLP = nullptr;            // pointer to MLP
    // AnyTrainer* p_learner = nullptr;        // pointer to training object
    // exyzSelection* p_selector = nullptr;    // pointer to selecting object
    // exyzSampling* p_sampler = nullptr;    // pointer to selecting object
    // LOTF* p_lotf = nullptr;                    // pointer to LOTF object
    std::vector<Configuration> training_set;// training set (for pure training regime)
    ErrorMonitor* p_errmon = nullptr;                    // error monitoring object

    Wrapper(const Settings&);
    virtual ~Wrapper();
    
    void Process(Configuration& exyz);        // function that does work configured according settings file (for example may perform fitting, EFS calculation, error caclulation, LOTF, etc.)
    void Release();;
};

#endif
