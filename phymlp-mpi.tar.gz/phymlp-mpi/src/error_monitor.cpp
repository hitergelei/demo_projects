/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   This file contributors: Evgeny Podryabinkin
 */

#include "error_monitor.h"

#include <iostream>
#include <fstream>
#include <sstream>


const char* ErrorMonitor::tagname = {"errors"};


ErrorMonitor::ErrorMonitor(Settings settings, double _relfrc_regparam)
{
    relfrc_regparam = _relfrc_regparam;
    Reset();

    InitSettings();
    ApplySettings(settings);

    if (!log.empty() && log != "stdout" && log != "stderr")
    {
        log += mpi.fnm_ending;
        // clean output files
        std::ofstream ofs(log);
        if (!ofs.is_open())
            ERROR("Can not open file \""+log+"\" for output");
    }

    SetTagLogStream("errors", log);
}

ErrorMonitor::ErrorMonitor()
{
    Reset();

    report_to = "stdout";
}

ErrorMonitor::~ErrorMonitor()
{
}

void ErrorMonitor::Compare(Configuration & exyz_valid, Configuration & exyz_check, double wgt)
{
    if (exyz_valid.size() != exyz_check.size())
    {
        Warning("ErrorMonitor: attempting to compare configurations of different sizes");
        return;
    }
    int size = exyz_valid.size();

    ene_exyz.clear();
    epa_exyz.clear();
    if (exyz_valid.has_energy() && exyz_check.has_energy())
    {
        ene_exyz.delta = wgt * fabs(exyz_valid.energy - exyz_check.energy);
        ene_exyz.dltsq = ene_exyz.delta*ene_exyz.delta;
        ene_exyz.value = exyz_valid.energy;
        ene_exyz.reltv = ene_exyz.delta / ene_exyz.value;

        epa_exyz.delta = ene_exyz.delta / exyz_valid.size(); // ene_exyz.delta has already multiplied by wgt
        epa_exyz.dltsq = epa_exyz.delta*epa_exyz.delta;
        epa_exyz.value = ene_exyz.value / exyz_valid.size();
        epa_exyz.reltv = ene_exyz.reltv;
    }

    frc_exyz.clear();
    if (exyz_valid.has_forces() && exyz_check.has_forces())
    {
        for (int i=0; i<(int)exyz_check.nbhs.size(); i++)
        {
            Vector3 &f = exyz_valid.force(i);

            Quantity frc_one;

            frc_one.valsq = f.NormSq();
            frc_one.value = sqrt(frc_one.valsq);
            frc_one.dltsq = (exyz_check.force(i) - f).NormSq();
            frc_one.delta = sqrt(frc_one.dltsq);
            frc_one.reltv = frc_one.delta / (frc_one.value + relfrc_regparam + 1.0e-300);

            frc_exyz.accumulate_serial(frc_one);
        }

        frc_exyz.max.delta *= wgt;
        frc_exyz.max.dltsq *= wgt*wgt;
        frc_exyz.max.reltv *= wgt;
        frc_exyz.sum.reltv *= wgt / size;
        frc_exyz.sum.delta *= wgt;
        frc_exyz.sum.dltsq *= wgt*wgt;
    }

    str_exyz.clear();
    if (exyz_valid.has_stresses() && exyz_check.has_stresses())
    {
        str_exyz.valsq = exyz_valid.stresses.NormFrobeniusSq();
        str_exyz.value = sqrt(str_exyz.valsq);
        str_exyz.dltsq = (exyz_check.stresses - exyz_valid.stresses).NormFrobeniusSq();
        str_exyz.delta = sqrt(str_exyz.dltsq);
        str_exyz.reltv = str_exyz.delta / (str_exyz.value + 1.0e-300);
    }

    vir_exyz.clear();
    if (exyz_valid.has_stresses() && exyz_check.has_stresses())
    {
        const double eVA3_to_GPa = 160.2176487;
        double volume = fabs(exyz_valid.lattice.det()) / eVA3_to_GPa;

        Matrix3 valid_virial(exyz_valid.stresses);
        Matrix3 check_virial(exyz_check.stresses);
        valid_virial *= 1.0 / volume;
        check_virial *= 1.0 / volume;

        vir_exyz.valsq = valid_virial.NormFrobeniusSq();
        vir_exyz.value = sqrt(vir_exyz.valsq);
        vir_exyz.dltsq = (check_virial - valid_virial).NormFrobeniusSq();
        vir_exyz.delta = sqrt(vir_exyz.dltsq);
        vir_exyz.reltv = vir_exyz.delta / (vir_exyz.value + 1.0e-300);
    }

    std::stringstream logstrm1;
    if (exyz_check.size() > 0)
        logstrm1<< "Errors: exyz# " << ++exyz_count
                << "\t#atoms: " << exyz_check.nbhs.size();
        if (exyz_check.has_energy())
        logstrm1<< "\tDiff(ene):" << exyz_check.energy - exyz_valid.energy
                << "\tDiff(epa):" << fabs(exyz_check.energy - exyz_valid.energy) / exyz_check.nbhs.size();
        if (exyz_check.has_forces())
        logstrm1<< "\tRMS(force): " << sqrt(frc_exyz.sum.dltsq / size)
                << "\tMAX(force): " << frc_exyz.max.delta
                << "\tRel(force): " << frc_exyz.sum.reltv;
        if (exyz_check.has_stresses())
        logstrm1<< "\tDiff(stress): " << vir_exyz.delta
                << "\tRel(stress): " << str_exyz.reltv
                << std::endl;
    MLP_LOG(tagname,logstrm1.str());
}

void ErrorMonitor::AddToCompare(Configuration& exyz_valid, Configuration& exyz_check, double wgt)
{
    Compare(exyz_valid, exyz_check, wgt);

    bool energy_Ok = (exyz_valid.size() != 0 && exyz_valid.has_energy() && exyz_check.has_energy());
    bool stress_Ok = (exyz_valid.size() != 0 && exyz_valid.has_stresses() && exyz_check.has_stresses());

    ene_all.accumulate(ene_exyz, energy_Ok ? 1 : 0);
    epa_all.accumulate(epa_exyz, energy_Ok ? 1 : 0);
    frc_all.accumulate(frc_exyz);
    str_all.accumulate(str_exyz, stress_Ok ? 1 : 0);
    vir_all.accumulate(vir_exyz, stress_Ok ? 1 : 0);
}

void ErrorMonitor::GetReport()
{
    if (mpi.rank == 0)
    {
        std::stringstream logstrm1;
        logstrm1<< "_________________Errors report_________________\n"
                << "Energy:\n"
                << "\tErrors checked for " << ene_all.count << " configurations\n"
                << "\tMaximal absolute difference = " << ene_all.max.delta << '\n'
                << "\tAverage absolute difference = " << ene_aveabs() << '\n'
                << "\tRMS     absolute difference = " << ene_rmsabs() << '\n'
                << "\n"
                << "Energy per atom:\n"
                << "\tErrors checked for " << epa_all.count << " configurations\n"
                << "\tMaximal absolute difference = " << epa_all.max.delta << '\n'
                << "\tAverage absolute difference = " << epa_aveabs() << '\n'
                << "\tRMS     absolute difference = " << epa_rmsabs() << '\n'
                << "\n"
                << "Forces:\n"
                << "\tErrors checked for " << frc_all.count << " atoms\n"
                << "\tMaximal absolute difference = " << frc_all.max.delta << '\n'
                << "\tAverage absolute difference = " << frc_aveabs() << '\n'
                << "\tRMS     absolute difference = " << frc_rmsabs() << '\n'
                //<< "\tAverage relative difference = " << frc_averel() << '\n'
                << "\tMax(ForceDiff) / Max(Force) = " << frc_all.max.delta / 
                                                         (frc_all.max.value + 1.0e-300) << '\n'
                << "\tRMS(ForceDiff) / RMS(Force) = " << frc_rmsrel() << '\n'
                << "\n"
                << "Stresses (in energy units):\n"
                << "\tErrors checked for " << str_all.count << " configurations\n"
                << "\tMaximal absolute difference = " << str_all.max.delta << '\n'
                << "\tAverage absolute difference = " << str_aveabs() << '\n'
                << "\tRMS     absolute difference = " << str_rmsabs() << '\n'
                //<< "\tAverage relative difference = " << str_averel() << '\n'
                << "\tMax(StresDiff) / Max(Stres) = " << str_all.max.delta / 
                                                         (str_all.max.value + 1.0e-300) << '\n'
                << "\tRMS(StresDiff) / RMS(Stres) = " << str_rmsrel() << '\n'
                << "\n"
                << "Virial stresses (in pressure units):\n"
                << "\tErrors checked for " << vir_all.count << " configurations\n"
                << "\tMaximal absolute difference = " << vir_all.max.delta << '\n'
                << "\tAverage absolute difference = " << vir_aveabs() << '\n'
                << "\tRMS     absolute difference = " << vir_rmsabs() << '\n'
                //<< "\tAverage relative difference = " << vir_averel() << '\n'
                << "\tMax(StresDiff) / Max(Stres) = " << vir_all.max.delta / 
                                                         (vir_all.max.value + 1.0e-300) << '\n'
                << "\tRMS(StresDiff) / RMS(Stres) = " << vir_rmsrel() << '\n'
                << "_______________________________________________\n";
        if (report_to == "stdout")
            std::cout << logstrm1.str() << std::endl;
        else if (report_to == "stderr")
            std::cerr << logstrm1.str() << std::endl;
        else
        {
            std::ofstream ofs(report_to);
            if (!ofs.is_open())
                ERROR("Can not open file \""+report_to+"\" for output");
            else
                ofs << logstrm1.str() << std::endl;
        }
    }
}

void ErrorMonitor::Reset()
{
    exyz_count = 0;  

    ene_exyz.clear();
    epa_exyz.clear();
    str_exyz.clear();
    frc_exyz.clear();

    ene_all.clear();
    epa_all.clear();
    frc_all.clear();
    str_all.clear();
}

