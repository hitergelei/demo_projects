/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   Contributors: Evgeny Podryabinkin
 */

#ifndef MLP_lammps_INTERFACE_H
#define MLP_lammps_INTERFACE_H


#include "basic_PES.h"


 // class allows one to use PES embedded in lammps. It is implemented via files exchange with lammps that should be launched by MLP for EFS calculation
class lammps_PES : public AnyPES, protected InitBySettings
{
private:
    const int io_max_attemps = 5; // number of attempts to read/write files 

    std::string input_filename;   // input filename for lammps with configuration (dump)
    std::string output_filename;  // input filename for lammps with configuration (dump)
    std::string start_command;    // command to OS environment launching lammps

    void InitSettings()           // Sets correspondence between variables and setting names in settings file
    {
        MakeSetting(input_filename, "input_file");
        MakeSetting(output_filename, "output_file");
        MakeSetting(start_command, "start_command");
    }

public:
    lammps_PES(const Settings& settings)
    {
        InitSettings();
        ApplySettings(settings);
    }
    lammps_PES(   const std::string& _input_filename,
                        const std::string& _output_filename,
                        const std::string& _start_command) :
                        input_filename(_input_filename),
                        output_filename(_output_filename),
                        start_command(_start_command) {}

    void CalcEFS(Configuration& conf);
};

#endif //#ifndef MLP_lammps_INTERFACE_H

