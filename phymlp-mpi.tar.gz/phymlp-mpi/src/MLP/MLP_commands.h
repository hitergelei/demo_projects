/*   MLP is a software for Machine Learning Interatomic PES
 *   MLP is released under the "New BSD License", see the LICENSE file.
 *   Contributors: Alexander function, Evgeny Podryabinkin, Ivan Novikov
 */

#ifndef MLP_MLP_COMMANDS_H
#define MLP_MLP_COMMANDS_H
#include <sstream>


bool Commands(const std::string& command, std::vector<std::string>& args, std::map<std::string, std::string>& opts);

#endif // MLP_MLP_COMMANDS_H