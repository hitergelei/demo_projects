#/bin/bash

# Preamble, common for all examples
MLP_EXE=../../bin/MLP
mkdir -p $TMP_DIR

# Body:
$MLP_EXE train 06.PhyMLP train.extxyz --save_to=pot.PhyMLP --iteration_limit=1000 --al_mode=nbh
