
#ifndef AUX_FUNC_H
#define AUX_FUNC_H

#include <fstream>
#include <stdio.h>
#include <string>
#include <vector>
#include <algorithm>  // hjchen
#include <unordered_map>  // hjchen



// #define CHECK(call)                                                                                \
//   do {                                                                                             \
//     const cudaError_t error_code = call;                                                           \
//     if (error_code != cudaSuccess) {                                                               \
//       fprintf(stderr, "CUDA Error:\n");                                                            \
//       fprintf(stderr, "    File:       %s\n", __FILE__);                                           \
//       fprintf(stderr, "    Line:       %d\n", __LINE__);                                           \
//       fprintf(stderr, "    Error code: %d\n", error_code);                                         \
//       fprintf(stderr, "    Error text: %s\n", cudaGetErrorString(error_code));                     \
//       exit(1);                                                                                     \
//     }                                                                                              \
//   } while (0)


#define PRINT_SCANF_ERROR(count, n, text)                                                          \
  do {                                                                                             \
    if (count != n) {                                                                              \
      fprintf(stderr, "Input Error:\n");                                                           \
      fprintf(stderr, "    File:       %s\n", __FILE__);                                           \
      fprintf(stderr, "    Line:       %d\n", __LINE__);                                           \
      fprintf(stderr, "    Error text: %s\n", text);                                               \
      exit(1);                                                                                     \
    }                                                                                              \
  } while (0)


#define PRINT_INPUT_ERROR(text)                                                                    \
  do {                                                                                             \
    fprintf(stderr, "Input Error:\n");                                                             \
    fprintf(stderr, "    File:       %s\n", __FILE__);                                             \
    fprintf(stderr, "    Line:       %d\n", __LINE__);                                             \
    fprintf(stderr, "    Error text: %s\n", text);                                                 \
    exit(1);                                                                                       \
  } while (0)


#define PRINT_KEYWORD_ERROR(keyword)                                                               \
  do {                                                                                             \
    fprintf(stderr, "Input Error:\n");                                                             \
    fprintf(stderr, "    File:       %s\n", __FILE__);                                             \
    fprintf(stderr, "    Line:       %d\n", __LINE__);                                             \
    fprintf(stderr, "    Error text: '%s' is an invalid keyword.\n", keyword);                     \
    exit(1);                                                                                       \
  } while (0)




void print_line_1(void);
void print_line_2(void);
FILE* my_fopen(const char* filename, const char* mode);
std::vector<std::string> get_tokens(const std::string& line);
std::vector<std::string> get_tokens(std::ifstream& input);
std::vector<std::string> get_tokens_without_unwanted_spaces(std::ifstream& input);
int get_int_from_token(const std::string& token, const char* filename, const int line);
float get_float_from_token(const std::string& token, const char* filename, const int line);
double get_double_from_token(const std::string& token, const char* filename, const int line);


static void read_xyz_line_1(std::ifstream& input, int& N)
{
  std::vector<std::string> tokens = get_tokens(input);
  if (tokens.size() != 1) {
    PRINT_INPUT_ERROR("The first line for the xyz file should have one value.");
  }
  N = get_int_from_token(tokens[0], __FILE__, __LINE__);
  if (N < 2) {
    PRINT_INPUT_ERROR("Number of atoms should >= 2.");
  } else {
    printf("Number of atoms is %d.\n", N);
  }
}


// 检查元素是否在周期表中
bool is_element_in_periodic_table(const std::string& element);


// 声明全局变量
extern std::unordered_map<std::string, int> species_mapping;






#endif // AUX_FUNC_H