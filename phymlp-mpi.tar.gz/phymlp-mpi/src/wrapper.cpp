/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   Contributors: Evgeny Podryabinkin
 */

#include <sstream>

#include "wrapper.h"
#include "PhyMLP.h"
#include "linear_regression.h"
#include "lammps_PES.h"
#include "PhyMLPr_trainer.h"
#include "lammps_PES.h"
#include "external_PES.h"

using namespace std;

const char* Wrapper::tagname = {"MLP"};

void Wrapper::SetUpMLP(const Settings& settings)
{
    MLPhyMLPR* p_PhyMLPr = nullptr;
    LinearRegression* p_linreg = nullptr;
    // StillingerWeberRadialBasis* p_sw = nullptr;

    // incorect scenarios
    if (!enable_MLP && !enable_abinitio && !enable_exyz_writing)
        ERROR("Nothing to be done");

    // if (enable_abinitio)
    //     p_abinitio = p_external = new ExternalPES(settings.ExtractSubSettings("abinitio"));
    // else
    //     p_abinitio = new VoidPES(); // trick for compatibility

    if (enable_MLP)
    {
        if (enable_select && enable_learn && !enable_lotf)
            ERROR("Configuration selection and MLP fitting cannot be activated at the same time");
        if (enable_sampling && enable_learn && !enable_lotf)
            ERROR("Configuration sampling and MLP fitting cannot be activated at the same time");
        if (enable_EFScalc && enable_learn && !enable_lotf)
            ERROR("EFS calculation and MLP fitting cannot be activated at the same time");
        if (enable_sampling && enable_select && !enable_lotf)
            ERROR("Configuration sampling and selection cannot be activated at the same time");
        if (!enable_EFScalc && !enable_learn && !enable_sampling && !enable_select && !enable_lotf)
            ERROR("No MLP routines activated");
        if (enable_lotf && !(enable_abinitio && enable_EFScalc && enable_learn && enable_sampling && enable_select))
            ERROR("EFS calculation, fitting, selection and sampling must be enabled in lotf scenario");
        if (MLP_fnm.empty())
            ERROR("MLP filename is not specified");
        if (enable_EFScalc && enable_abinitio && !enable_lotf)
            Warning("abinitio calculation will be overwriten by MLP calculation");

        ifstream ifs(MLP_fnm, ios::binary);
        if (!ifs.is_open())
            ERROR("Can not open file \""+MLP_fnm+"\" for MLP loading");
        ifs >> MLP_type;
        ifs.close();

        //cout << "MLP_fnm = " << MLP_fnm << endl;
        if (MLP_type == "PhyMLP")
        {
            Message("MLP type is non-linear PhyMLP");
            p_MLP = p_PhyMLPr = new MLPhyMLPR(MLP_fnm);
        }
        else
            ERROR("unrecognized MLP type \""+MLP_type+"\" detected in \""+MLP_fnm+"\"");

    //     if (!enable_lotf)
    //     {
    //         if (enable_sampling)
    //             p_sampler = new exyzSampling(p_MLP, 
    //                                         MLP_fnm, 
    //                                         settings.ExtractSubSettings("extrapolation_control"));

    //         if (enable_select)
    //             p_selector = new exyzSelection(p_MLP, settings.ExtractSubSettings("select"));

    //         if (enable_learn)
    //             p_learner = new PhyMLPR_trainer(p_PhyMLPr, settings.ExtractSubSettings("fit"));
    //     }
    //     else
    //     {
    //         try // attempting to read selection state from the file
    //         {
    //             p_sampler = new exyzSampling(p_MLP, 
    //                                         MLP_fnm, 
    //                                         settings.ExtractSubSettings("extrapolation_control"));

    //             exyzSelection tmp_sel(p_MLP, settings.ExtractSubSettings("select"));
    //             p_sampler->batch_size = tmp_sel.batch_size;
    //             p_sampler->swap_limit = tmp_sel.swap_limit;
    //             p_sampler->selected_exyzs_fnm = tmp_sel.selected_exyzs_fnm;
    //             p_sampler->state_save_fnm = tmp_sel.state_save_fnm;
    //             p_sampler->slct_log = tmp_sel.slct_log;
    //         }
    //         catch (MLPException& exception) // attempting to initilize selection from scratch
    //         {
    //             if (exception.message == "No selection data provided with MLP")
    //             {
    //                 exyzSelection tmp_sel(p_MLP, settings.ExtractSubSettings("select"));
    //                 p_sampler = new exyzSampling(tmp_sel, settings.ExtractSubSettings("extrapolation_control"));
    //             }
    //             else
    //                 ERROR("Unable to initilaize LOTF.\n" + exception.message);
    //         }
    //         p_learner = new PhyMLPR_trainer(p_PhyMLPr, settings.ExtractSubSettings("fit"));
    //         p_lotf = new LOTF(p_external,
    //                           p_sampler,
    //                           p_learner,
    //                           settings.ExtractSubSettings("lotf"));
    //     }
    }
    else
        enable_lotf = enable_learn = enable_select = enable_sampling = enable_EFScalc = false;

    if (enable_err_check)
        p_errmon = new ErrorMonitor(settings.ExtractSubSettings("check_errors"));

    // checking and cleaning output configurations file (it is better to crash with error in the beginning)
    if (enable_exyz_writing)
    {
#ifdef MLP_MPI
        string exyzs_fnm_many(exyzs_fnm);
        if (!exyzs_fnm.empty() &&
            exyzs_fnm != "stdout" &&
            exyzs_fnm != "stderr")
            exyzs_fnm_many += mpi.fnm_ending;
        
        ifstream ifs(exyzs_fnm_many);
        if (ifs.is_open())
        { // clean the content
            ifs.close();
            ofstream ofs_tmp(exyzs_fnm_many);
            if (!ofs_tmp.is_open())
                ERROR("Can't open .exyzs file \"" + exyzs_fnm_many + "\" for output");
			remove(exyzs_fnm_many.c_str());
        }
        if (mpi.rank == 0)
        {
            ifstream ifs(exyzs_fnm);
            if (ifs.is_open())
            { // clean the content
                ofstream ofs_tmp(exyzs_fnm);
                if (!ofs_tmp.is_open())
                    ERROR("Can't open .exyzs file \"" + exyzs_fnm + "\" for output");
            }
        }
#else
        ofstream ofs_tmp(exyzs_fnm);
        if (!ofs_tmp.is_open())
            ERROR("Can't open .exyzs file \"" + exyzs_fnm + "\" for output");
#endif
    }
}

Wrapper::Wrapper(const Settings& settings)
{
    InitSettings();
    ApplySettings(settings);

    Message("Wrapper initialization");
    
    if ( 0 == mpi.rank )
        PrintSettings();

    if (!log_output.empty() &&
        log_output != "stdout" &&
        log_output != "stderr")
            log_output += mpi.fnm_ending;

    if (!enable_lotf)
        log_output.clear();

    SetTagLogStream("MLP", log_output); // 

    SetUpMLP(settings);

    Message("Wrapper initialization complete");
}

Wrapper::~Wrapper()
{
    Release();

    std::stringstream logstrm1;
    logstrm1 << endl;   // to keep previous messages printed with '\r'
    MLP_LOG(tagname,logstrm1.str()); logstrm1.str("");

    if (p_errmon != nullptr)
        delete p_errmon;

    // if (p_lotf != nullptr)
    //     delete p_lotf;

    // if (p_selector != nullptr)
    //     delete p_selector;

    // if (p_sampler != nullptr)
    //     delete p_sampler;

    // if (p_learner != nullptr)
    //     delete p_learner;

    if (p_MLP != nullptr)
        delete p_MLP;

    // if (p_abinitio != nullptr)
    //     delete p_abinitio;

    Message("Wrapper object has been destroyed");
}

void Wrapper::Process(Configuration & exyz)
{
    // if (!enable_lotf || enable_err_check)
    //     p_abinitio->CalcEFS(exyz);

    if (enable_err_check)
        exyz_valid = exyz; // This placed before CalcEFS(exyz) for correct work with VoidPES

    // if (enable_lotf)
    //     p_lotf->CalcEFS(exyz);
    // else
    // {
    //     if (enable_sampling)
    //         p_sampler->Evaluate(exyz);

    //     if (enable_select)
    //         p_selector->Process(exyz);

    //     if (enable_learn)
    //     {
    //         training_set.push_back(exyz);
    //         learn_count++;
    //     }

        if (enable_EFScalc)
        {
            p_MLP->CalcEFS(exyz);
            PhyMLP_count++;
        }
    // }

    if (enable_err_check)
        p_errmon->AddToCompare(exyz_valid, exyz);

    if (!exyzs_fnm.empty() && (call_count % (skip_saving_N_exyzs+1) == 0))
    {
        if (exyz.CommGhostData != nullptr)
        {
            double* comm_arr = (exyz.has_forces() ? &exyz.force(0, 0) : nullptr);
            exyz.CommGhostData(comm_arr);

            for (int i=0; i<exyz.size(); i++)
                if (exyz.ghost_inds.count(i) != 0)
                {
                    exyz.force(i, 0) = 0.0;
                    exyz.force(i, 1) = 0.0;
                    exyz.force(i, 2) = 0.0;
                }

            exyz.AppendToFile(exyzs_fnm);
        }
        else 
            if (exyz.is_mpi_splited)
                exyz.AppendToFile(exyzs_fnm);
            else
                if (exyz.size() > 0)
                    exyz.AppendToFile(exyzs_fnm + mpi.fnm_ending);
    }

    call_count++;
    std::stringstream logstrm1;
    logstrm1 << "MLP: processed "  << call_count 
            << "\tAbinitio_calcs "  << abinitio_count
            << "\tPhyMLP_calcs "       << PhyMLP_count
            << "\texyz_learned "     << learn_count
            << endl;
    MLP_LOG(tagname,logstrm1.str());
}

// function that does work configured according settings file (for example may perform fitting, EFS calculation, error caclulation, LOTF, etc.)

void Wrapper::Release()
{
    // if (enable_lotf)
    // {
    //     p_lotf->UpdateMLP();
    //     return;
    // }

    // if (enable_learn)
    // {
        
    //     int global_learn_count = 0;
    //     MPI_Allreduce(&learn_count, &global_learn_count, 1, MPI_INT, MPI_SUM, mpi.comm);
    //     if (global_learn_count > 0)
    //         p_learner->Train(training_set);
    //     learn_count = 0;
    //     if (mpi.rank == 0)
    //         p_learner->p_MLP->Save(p_learner->MLP_fitted_fnm);
    // }

    // if (enable_select)
    // {
    //     p_selector->Select((p_selector->swap_limit>0) ? p_selector->swap_limit : HUGE_INT);
    // }

    if (enable_err_check)
    {
        if (mpi.rank==0)
            p_errmon->GetReport();
    }

    MPI_Barrier(mpi.comm);
}
