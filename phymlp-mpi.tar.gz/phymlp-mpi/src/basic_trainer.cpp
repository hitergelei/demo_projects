/*   This software is called MLP for Machine Learning Interatomic PES.
 *   MLP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 *
 *   This file contributors: Evgeny Podryabinkin
 */

#include "basic_trainer.h"


const char* AnyTrainer::tagname = {"fit"};

AnyTrainer::AnyTrainer(AnyLocalMLP * _p_MLP, const Settings & settings) :
    p_MLP(_p_MLP)
{
    InitSettings();
    ApplySettings(settings);

    if (mpi.rank == 0)
    {
        std::ifstream ifs(MLP_fitted_fnm);
        if (ifs.is_open())
            Warning("File " + MLP_fitted_fnm + " already exists and will be overwritten during the training procedure!");
    }

    SetTagLogStream("fit", fit_log);

    Message("Basic trainer initialization complete");
}


